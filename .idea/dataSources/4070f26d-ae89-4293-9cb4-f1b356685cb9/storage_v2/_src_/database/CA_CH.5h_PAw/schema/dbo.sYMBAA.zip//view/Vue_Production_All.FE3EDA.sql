create view Vue_Production_All as (SELECT tp.NT, tp.Code_Site, tp.Code_Tache, SUM(tp.Quantite_1+tp.Quantite_2+tp.Quantite_3) as Qte_Produite
FROM Tab_Production tp  where tp.Code_Type_Production='01' and tp.Prevu_Realiser = 'R'
GROUP BY tp.nt, tp.code_site, tp.code_tache)
go

