----Creation FUNCTION [dbo].[Cte_Float]
CREATE FUNCTION [dbo].[Cte_Float] (
@Code_Parametre varchar(10)
) returns float

as 
begin
declare @Float_Param float
set @Float_Param=(SELECT CAST(REPLACE(Contenue_Parametre,';','') as float) AS Param_Flaot FROM Tab_Constantes_Parametrables 
WHERE Code_Parametre = @Code_Parametre AND Est_Bloquer = 0)
RETURN @Float_Param
end;
go

