CREATE TRIGGER TR_Update_Date_Modification_Tab_Famille_Poste_Travail ON Tab_Famille_Poste_Travail
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Famille_Poste_Travail AS A
														INNER JOIN INSERTED AS B ON A.Code_Famille_Poste_Travail = B.Code_Famille_Poste_Travail
														INNER JOIN DELETED AS C ON A.Code_Famille_Poste_Travail = C.Code_Famille_Poste_Travail
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

