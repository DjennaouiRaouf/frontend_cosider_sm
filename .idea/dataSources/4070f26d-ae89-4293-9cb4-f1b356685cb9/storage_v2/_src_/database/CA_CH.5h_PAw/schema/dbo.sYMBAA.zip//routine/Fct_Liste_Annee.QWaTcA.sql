
/*************Fin**************************************/

/****** UserDefinedFunction [dbo].[Fct_Liste_Annee]  ******/
Create FUNCTION [dbo].[Fct_Liste_Annee] (@Date_Debut date,@Date_Fin date) 
returns  @Tableau_Des_Annees TABLE (
	
	[Annee] varchar(4))

as 
begin

Declare @Anne_Min int
Declare @Anne_Max int

if (ISDATE(cast(@Date_Debut as varchar))=1 and ISDATE(cast(@Date_Fin as varchar))=1) 
begin
select @Anne_Min= YEAR(@Date_Debut)
select @Anne_Max= YEAR(@Date_Fin)

while (@Anne_Min<=@Anne_Max)
 
begin

insert into @Tableau_Des_Annees ([Annee])

select @Anne_Min

set @Anne_Min=@Anne_Min+1
end

end
RETURN 

end;
go

