CREATE TRIGGER TR_Update_Date_Modification_Tab_Taches_Personnalisees ON Tab_Taches_Personnalisees
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Taches_Personnalisees AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Matricule, A.Code_Taches_Generique) = CONCAT (B.Matricule, B.Code_Taches_Generique)
														INNER JOIN DELETED AS C ON CONCAT (A.Matricule, A.Code_Taches_Generique) = CONCAT (C.Matricule, C.Code_Taches_Generique)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

