
CREATE   procedure sp_synch_Tab_Agent_Carriere @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Carriere] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Carriere] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )) and ( Target.[Date_Debut] = Source.[Date_Debut] ) and ( Target.[Est_Bloquer] = Source.[Est_Bloquer] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Nature] = Source.[Nature],
Target.[Mat_Exper] = Source.[Mat_Exper],
Target.[Code_Filiale] = Source.[Code_Filiale],
Target.[Code_site] = Source.[Code_site],
Target.[Raison_Social] = Source.[Raison_Social],
Target.[Libelle_poste_travail] = Source.[Libelle_poste_travail],
Target.[Code_Poste_Travail] = Source.[Code_Poste_Travail],
Target.[Date_Fin] = Source.[Date_Fin],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Date_Debut],
[Est_Bloquer],
[Nature],
[Mat_Exper],
[Code_Filiale],
[Code_site],
[Raison_Social],
[Libelle_poste_travail],
[Code_Poste_Travail],
[Date_Fin],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Date_Debut],
Source.[Est_Bloquer],
Source.[Nature],
Source.[Mat_Exper],
Source.[Code_Filiale],
Source.[Code_site],
Source.[Raison_Social],
Source.[Libelle_poste_travail],
Source.[Code_Poste_Travail],
Source.[Date_Fin],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

