


-- VUE CALCULE PAIE COURANTE

CREATE view [dbo].[Vue_Calcule_Paie_Courante] (Matricule,Code_Rubrique,Libelle_Rubrique,Base,Taux,Montant,Retenue,Gains,Code_Structure)
as select a.matricule as Matricule,a.code_rubrique as Code_Rubrique,b.Libelle_Rubrique as Libelle_Rubrique,a.Base as Base,a.Taux as Taux,
a.Montant as Montant,COALESCE(c.Retenue,0) as Retenue,
COALESCE(d.gaine,0) as Gains,e.Code_Structure from  Tab_Calcul_Paie as a

cross apply (select code_rubrique,Libelle_Rubrique,CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature) AS Type_Nature_Rub, Sens from 
Tab_Plan_Rubriques where a.code_rubrique=code_rubrique and CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature)<>('CZ') and 
CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature)<>('CR')) as b

outer apply(select sum(c.Montant) over (partition by c.Matricule ) as Retenue from Tab_Calcul_Paie as c
where (c.code_rubrique=a.code_rubrique) and (c.Mmaadb=a.Mmaadb or (a.Mmaadb is null and c.Mmaadb is null)) and b.Type_Nature_Rub<>('CZ') and
b.Type_Nature_Rub<>('CR') and a.Matricule=c.Matricule and b.Sens<0) as c 

outer apply(select  sum(d.Montant) over (partition by d.Matricule ) as gaine from Tab_Calcul_Paie as d
where (d.code_rubrique=a.code_rubrique) and (d.Mmaadb=a.Mmaadb or (a.Mmaadb is null and d.Mmaadb is null)) and b.Type_Nature_Rub<>('CZ') and
b.Type_Nature_Rub<>('CR') and a.Matricule=d.Matricule and b.Sens>0) as d

cross apply( select top 1 Matricule,Code_Structure from Tab_Information_Bulletin_Agent
where a.Matricule=Matricule AND Est_Bloquer = 0
order by Code_Information_Bulletin_Agent DESC ) as e 

go

