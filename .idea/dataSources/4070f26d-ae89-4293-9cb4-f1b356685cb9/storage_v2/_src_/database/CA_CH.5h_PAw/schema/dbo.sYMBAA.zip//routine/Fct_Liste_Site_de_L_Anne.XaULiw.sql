

-- FONCTION Liste site en cours de l'anne

CREATE function [dbo].[Fct_Liste_Site_de_L_Anne] (@Date_Debut date,@Date_Fin date) 
returns table as return
(
select distinct a.Code_Site,b.Code_Filiale,d.Libelle_Filiale,b.Code_Division,c.Libelle_Division as Division from
(select distinct Code_Site from Tab_Production where (mmaa between @Date_Debut and @Date_Fin) and Code_site is not null 
union all
 select distinct recepteur from Tab_Production where (mmaa between @Date_Debut and @Date_Fin) and Type_Prestation=1 and recepteur is not null and recepteur <>''
 union all
 select distinct Code_Site from Tab_Detaille_Charge where (mmaa between @Date_Debut and @Date_Fin) and Code_site is not null 
union all
 select distinct recepteur from Tab_Detaille_Charge where (mmaa between @Date_Debut and @Date_Fin) and Type_Prestation=1 and recepteur is not null and recepteur <>''
 union all
 select distinct Code_Site from Tab_Sortie_Magasin_Vesrs_NT where (mmaa between @Date_Debut and @Date_Fin) and Code_site is not null 

 ) as a
  inner join Tab_Site as b on a.Code_site=b.Code_site
  inner join Tab_Division as c on c.Code_Division=b.Code_Division
  inner join Tab_Filiale as d on d.Code_Filiale=b.Code_Filiale
     
)


go

