CREATE TRIGGER TR_Update_Date_Modification_Tab_Caisse_Cotisation ON Tab_Caisse_Cotisation
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Caisse_Cotisation AS A
														INNER JOIN INSERTED AS B ON A.Code_Caisse = B.Code_Caisse
														INNER JOIN DELETED AS C ON A.Code_Caisse = C.Code_Caisse
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

