
CREATE   procedure sp_synch_Tab_Agent_Formation @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Formation] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Formation] AS Source
ON (1=1 and ( Target.[Code_Agent_Formation] = ('''+@code+'''+Source.[Code_Agent_Formation] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Code_Formation] = ('''+@code+'''+Source.[Code_Formation]),
Target.[Obtention_Diplome] = Source.[Obtention_Diplome],
Target.[Mode_Prise_En_Charge] = Source.[Mode_Prise_En_Charge],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Agent_Formation],
[Matricule],
[Code_Formation],
[Obtention_Diplome],
[Mode_Prise_En_Charge],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Agent_Formation]),
('''+@code+'''+Source.[Matricule]),
('''+@code+'''+Source.[Code_Formation]),
Source.[Obtention_Diplome],
Source.[Mode_Prise_En_Charge],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

