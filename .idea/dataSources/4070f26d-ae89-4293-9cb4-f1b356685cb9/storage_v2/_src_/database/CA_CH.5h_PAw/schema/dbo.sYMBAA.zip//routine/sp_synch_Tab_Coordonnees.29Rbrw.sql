CREATE   procedure sp_synch_Tab_Coordonnees @db_source varchar(max), @code varchar(max)
as
begin
    
    DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Coordonnees] AS Target
    USING ['+@db_source+'].[dbo].[Tab_Coordonnees] AS Source
    ON (1=1 and ( (concat(Target.[Code_Famille_Coordonnee],Target.[Matricule],Target.[Code_Agence],Target.[Code_Entreprise],Target.[Code_Filiale],Target.[Code_site],Target.[Code_Banque],Target.[Code_Caisse],Target.[Code_Organisme],Target.[Code_Tiers],Target.[Nature],Target.[Occ],Target.[Est_Bloquer]) = concat(Source.[Code_Famille_Coordonnee],('''+@code+'''+Source.[Matricule]),('''+@code+'''+Source.[Code_Agence]),Source.[Code_Filiale],Source.[Code_site],('''+@code+'''+Source.[Code_Banque]),('''+@code+'''+Source.[Code_Caisse]),Source.[Code_Organisme],Source.[Code_Tiers],Source.[Nature],Source.[Occ],Source.[Est_Bloquer]) 
                            and (Source.[Code_Entreprise] is null))))
    WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
    THEN
    UPDATE SET Target.[Contenue] = Source.[Contenue],
    Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
    Target.[Date_Modification]=Source.[Date_Modification]
    WHEN NOT MATCHED and (Source.[Code_Entreprise] is null)
    THEN
    INSERT (
    [Code_Famille_Coordonnee],
    [Contenue],
    [Matricule],
    [Code_site],
    [Code_Filiale],
    [Code_Agence],
    [Code_Banque],
    [Code_Caisse],
    [Code_Organisme],
    [Code_Tiers],
    [Nature],
    [Occ],
    [Est_Bloquer],
    [User_ID],
    [Date_Modification]
    )
    VALUES (
    Source.[Code_Famille_Coordonnee],
    Source.[Contenue],
    ('''+@code+'''+Source.[Matricule]),
    Source.[Code_site],
    Source.[Code_Filiale],
    ('''+@code+'''+Source.[Code_Agence]),
    ('''+@code+'''+Source.[Code_Banque]),
    ('''+@code+'''+Source.[Code_Caisse]),
    ('''+@code+'''+Source.[Code_Organisme]),
    Source.[Code_Tiers],
    Source.[Nature],
    Source.[Occ],
    Source.[Est_Bloquer],
    case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
    Source.[Date_Modification]
    );'
    exec (@sql_interne)
end
go

