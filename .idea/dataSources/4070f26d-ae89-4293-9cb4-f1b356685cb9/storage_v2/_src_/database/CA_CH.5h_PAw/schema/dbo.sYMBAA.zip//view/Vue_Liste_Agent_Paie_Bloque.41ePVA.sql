
-- VUE  LISTE AGENT PAIE BLOQUEE

CREATE View [dbo].[Vue_Liste_Agent_Paie_Bloque] (Matricule,Nom,Prenom,Date_Recrutement,Libelle_Evenement,Date_Evenement,Ref_Decision,Code_Evenement_Agent)
as select a.Matricule,a.Nom,a.Prenom,b.Date_Debut_Contrat as Date_Recrutement,g.Libelle_Evenement,g.Date_Evenement,c.Ref_Decision,g.Code_Evenement_Agent FROM Tab_Agent AS a

CROSS apply (select top (1) Date_Debut_Contrat from Tab_Agent_Contrat 

where a.Matricule=Matricule AND Est_Bloquer = 0 order by Tab_Agent_Contrat.Nbr_Contrat ASC ) as b

CROSS APPLY  (SELECT TOP (1) Code_Evenement_Agent ,Avec_Blocage_Paie,Avec_Deblocage_Provisoire_Paie,Date_Evenement,Avec_Depart,Libelle_Evenement 
FROM Tab_Evenement_Agent AS g 
inner join Tab_Evenement_RH AS h on g.Code_Evenement = h.Code_Evenement 
where g.Matricule = a.Matricule AND g.Est_Bloquer = 0 ORDER BY g.Code_Evenement_Agent DESC) AS g

outer APPLY (select Ref_Decision from Tab_Decisions as f
inner join Tab_Evenement_Agent as b on f.Code_Decision=b.Code_Decision
where f.Matricule=a.Matricule and g.Code_Evenement_Agent=b.Code_Evenement_Agent ) as c

where  (g.Avec_Blocage_Paie=1) or (g.Avec_Depart=1) or (g.Avec_Deblocage_Provisoire_Paie = 1)

go

