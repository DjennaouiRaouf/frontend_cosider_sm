CREATE TRIGGER TR_Update_Date_Modification_Tab_Liste_Champ_Document ON Tab_Liste_Champ_Document
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Liste_Champ_Document AS A
														INNER JOIN INSERTED AS B ON A.ID_Champ = B.ID_Champ
														INNER JOIN DELETED AS C ON A.ID_Champ = C.ID_Champ
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

