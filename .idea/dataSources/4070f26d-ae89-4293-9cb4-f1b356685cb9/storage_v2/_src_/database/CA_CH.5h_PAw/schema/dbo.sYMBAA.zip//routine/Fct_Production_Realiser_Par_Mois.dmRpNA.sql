
-- FONCTION Production_Realiser_Par_Mois

CREATE function [dbo].[Fct_Production_Realiser_Par_Mois] (@Date_Debut date,@Date_Fin date) 
returns table as return
(
SELECT 
 a.*,(isnull(b.Total_Mensuel_Realise_prod_propre,0)-isnull(d.Total_Mensuel_Realise_prod_ST,0)) as Total_Mensuel_Realise_prod_propre,
 isnull(c.Total_Mensuel_Realise_prod_preste_Interne,0) as Total_Mensuel_Realise_prod_preste_Interne,
 isnull(c.Total_Mensuel_Realise_prod_preste_Externe,0) as Total_Mensuel_Realise_prod_preste_Externe,
 isnull(d.Total_Mensuel_Realise_prod_ST,0) as Total_Mensuel_Realise_prod_ST

FROM [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a
left join
(select Code_site,sum(Valeur_1+Valeur_2+Valeur_3)  Total_Mensuel_Realise_prod_propre from Tab_Production 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Code_Type_Production='01'
group by Code_site) as b on a.Code_site=b.Code_site 

left join

(select a.Code_site, 
(isnull(b.Total_Mensuel_Realise_prod_preste1,0)+isnull(c.Total_Mensuel_Realise_prod_preste2,0)+isnull(f.Total_Mensuel_Realise_prod_preste3,0)) as Total_Mensuel_Realise_prod_preste_Interne, 
(isnull(d.Total_Mensuel_Realise_prod_preste_Externe1,0)+isnull(e.Total_Mensuel_Realise_prod_preste_Externe2,0)) as Total_Mensuel_Realise_prod_preste_Externe
from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a
left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Mensuel_Realise_prod_preste1 from Tab_Production 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Code_Type_Production='02' and Type_Prestation in (1,2)
group by Code_site) as b on a.Code_site=b.Code_site
left join
(select Recepteur,isnull(sum(Valeur_1)*-1,0) as Total_Mensuel_Realise_prod_preste2 from Tab_Production 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Code_Type_Production='02' and Type_Prestation=1
group by Recepteur) as c on a.Code_site=c.Recepteur

left join
(select Code_site,isnull(sum(Valeur),0) as Total_Mensuel_Realise_prod_preste3 from Tab_Detaille_Charge 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Type_Prestation=2
group by Code_site) as f on a.Code_site=f.Code_site

left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Mensuel_Realise_prod_preste_Externe1 from Tab_Production 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Code_Type_Production='02' and Type_Prestation=3
group by Code_site) as d on a.Code_site=d.Code_site

left join
(select Code_site,isnull(sum(Valeur),0) as Total_Mensuel_Realise_prod_preste_Externe2 from Tab_Detaille_Charge 
where mmaa=@Date_Fin and Prevu_Realiser='R' and Type_Prestation=3
group by Code_site) as e on a.Code_site=e.Code_site


)  as c on a.Code_site=c.Code_site

left join

(select a.Code_site,sum(Valeur_1) as Total_Mensuel_Realise_prod_ST from Tab_Production as a
where mmaa=@Date_Fin and Prevu_Realiser='R' and Code_Type_Production='03'
group by a.Code_site) as d on a.Code_site=d.Code_site
     
)
go

