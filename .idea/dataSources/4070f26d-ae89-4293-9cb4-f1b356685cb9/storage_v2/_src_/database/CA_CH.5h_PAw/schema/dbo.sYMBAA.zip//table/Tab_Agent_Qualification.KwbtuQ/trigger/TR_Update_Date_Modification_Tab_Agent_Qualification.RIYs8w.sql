CREATE TRIGGER TR_Update_Date_Modification_Tab_Agent_Qualification ON Tab_Agent_Qualification
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Agent_Qualification AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Matricule, A.Code_Qualification) = CONCAT (B.Matricule, B.Code_Qualification)
														INNER JOIN DELETED AS C ON CONCAT (A.Matricule, A.Code_Qualification) = CONCAT (C.Matricule, C.Code_Qualification)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

