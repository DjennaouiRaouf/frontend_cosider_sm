

-- VUE LISTE AGENT ACTIF PAYER

CREATE VIEW [dbo].[Vue_Liste_Agent_Actif_Payer] (Matricule,Nom,Prenom,Avec_Chomage_Intemperie,Avec_Cacobath,Avec_Mutuel,Avec_Oprebat,
Montant_Assurance_Groupe,Avec_Handicap,Avec_Abattement_Cnas,
Taux_Cnas,Avec_Abattement_IRG,Est_Apprenti,Poste_Travail,Structure,Acronyme,Classification,Code_Niveau_Resp,Date_Fin_Contrat,Taux_Statut_Horaire)

AS SELECT  a.Matricule,a.Nom,a.Prenom,a.Avec_Chomage_Intemperie,a.Avec_Cacobath,a.Avec_Mutuel,a.Avec_Oprebat,a.Montant_Assurance_Groupe,
a.Handicap,a.Avec_Abattement_Cnas,a.Taux_Cnas,a.Abattement_IRG,a.Est_Apprenti,c.Libelle_poste_travail,f.Libelle_Structure,f.Acronyme,
c.Classification,c.Code_Niveau_Resp,b.Date_Fin_Contrat,h.Taux_Statut_Horaire FROM Tab_Agent AS a

outer apply (SELECT top (1) b.Date_Fin_Contrat,b.Situation_Contrat,b.Date_Debut_Contrat,

    IIF(b.Nbr_Contrat > 1,
    (SELECT Date_Fin_Contrat FROM Tab_Agent_Contrat WHERE a.Matricule=Matricule AND Est_Bloquer = 0 AND b.Nbr_Contrat-1 =  Nbr_Contrat )
    ,NULL) AS DateFinContratPrec 
    
    from Tab_Agent_Contrat as b

where a.Matricule = b.Matricule AND b.Est_Bloquer = 0 order by b.Nbr_Contrat desc) as b

OUTER APPLY (SELECT TOP (1) d.Libelle_poste_travail,c.Code_Contrat,c.Classification,d.Code_Niveau_Resp FROM Tab_Promotion_Agent AS c , Tab_Poste_Travail AS d

WHERE d.Code_Poste_Travail = c.Code_Poste_Travail AND c.Matricule = a.Matricule AND C.Est_Bloquer = 0 ORDER BY Nbr_Promtion_Agent desc) AS c

OUTER APPLY (select c.Libelle_Structure,c.Acronyme,cast(d.Jour_Cloture_Mouv_RH_Paie as int) as JourCloture,[dbo].[Cte_Date]('Mois') as MoisPaieCourant,
DATEADD(month, DATEDIFF(month, 0, [dbo].[Cte_Date]('Mois'))-1, cast(d.Jour_Cloture_Mouv_RH_Paie as int)) AS DateDebutMoisPaie,
DATEADD(month, DATEDIFF(month, 0, [dbo].[Cte_Date]('Mois')), cast(d.Jour_Cloture_Mouv_RH_Paie as int)-1) AS DateFinMoisPaie
from 
(select top 1 Code_Structure from  Tab_Affectation_Agent  
where a.Matricule=Matricule order by Nbr_Affectation desc) as b
inner join Tab_Structures as c on c.Code_Structure=b.Code_Structure
inner join Tab_Site as d on c.Code_Site=d.Code_site) AS f

OUTER APPLY  (SELECT TOP (1) DATEDIFF(day,g.Date_Evenement,DATEADD(day,f.JourCloture,f.MoisPaieCourant)) AS NbrJoursRestant,
h.Avec_Depart,h.Type_Blocage_Paie,h.Avec_Retour,g.Avec_Blocage_Paie,g.Avec_Deblocage_Provisoire_Paie,
g.Date_Evenement,g.Date_Retour_Reel,g.Date_Fin_Evenement_Prevu FROM Tab_Evenement_Agent AS g ,Tab_Evenement_RH AS h

WHERE g.Code_Evenement = h.Code_Evenement AND g.Matricule = a.Matricule AND g.Est_Bloquer = 0 ORDER BY g.Code_Evenement_Agent DESC) AS g

cross apply (select TOP (1) sh.Taux_Statut_Horaire from Tab_Information_Bulletin_Agent as ib,Tab_Statut_Horaire as sh 
where sh.Code_Statut_Horaire=ib.Code_Statut_Horaire and a.Matricule=Matricule and ib.Est_Bloquer = 0
order by Code_Information_Bulletin_Agent DESC )as h

WHERE (((g.Avec_Depart = 0 or g.Avec_Depart is null) or (g.Avec_Depart = 1 and g.Avec_Retour = 1 and CURRENT_TIMESTAMP>= g.Date_Retour_Reel) OR g.Type_Blocage_Paie = 0) 

AND ( ( b.Date_Fin_Contrat > f.DateDebutMoisPaie OR b.Date_Fin_Contrat is null ) 
AND (( b.Date_Debut_Contrat <= f.DateFinMoisPaie ) OR  ( b.DateFinContratPrec >= f.DateDebutMoisPaie )) ) ) AND b.Situation_Contrat = 2

OR (g.Avec_Deblocage_Provisoire_Paie=1)
OR (g.Type_Blocage_Paie = 2 and g.NbrJoursRestant < (day(EOMONTH(g.Date_Evenement) ))
AND g.NbrJoursRestant <> 0)

go

