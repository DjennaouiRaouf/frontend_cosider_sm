CREATE TRIGGER TR_Update_Date_Modification_Tab_Agence ON Tab_Agence
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Agence AS A
														INNER JOIN INSERTED AS B ON A.Code_Agence = B.Code_Agence
														INNER JOIN DELETED AS C ON A.Code_Agence = C.Code_Agence
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

