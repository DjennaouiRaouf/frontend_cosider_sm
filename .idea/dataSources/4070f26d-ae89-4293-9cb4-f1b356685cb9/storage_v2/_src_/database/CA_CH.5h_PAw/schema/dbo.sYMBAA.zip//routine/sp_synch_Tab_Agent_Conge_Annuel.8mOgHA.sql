
CREATE   procedure sp_synch_Tab_Agent_Conge_Annuel @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Conge_Annuel] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Conge_Annuel] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )) and ( Target.[Date_Debut_Conge] = Source.[Date_Debut_Conge] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Date_Retour_Prevu] = Source.[Date_Retour_Prevu],
Target.[Date_Retour_Reel] = Source.[Date_Retour_Reel],
Target.[Exercice] = Source.[Exercice],
Target.[Nbr_Jours_Demander] = Source.[Nbr_Jours_Demander],
Target.[Nbr_Jours_Effectif] = Source.[Nbr_Jours_Effectif],
Target.[Etat_Conge] = Source.[Etat_Conge],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Date_Debut_Conge],
[Date_Retour_Prevu],
[Date_Retour_Reel],
[Exercice],
[Nbr_Jours_Demander],
[Nbr_Jours_Effectif],
[Etat_Conge],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Date_Debut_Conge],
Source.[Date_Retour_Prevu],
Source.[Date_Retour_Reel],
Source.[Exercice],
Source.[Nbr_Jours_Demander],
Source.[Nbr_Jours_Effectif],
Source.[Etat_Conge],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

