CREATE TRIGGER TR_Update_Date_Modification_Tab_Document_Word ON Tab_Document_Word
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Document_Word AS A
														INNER JOIN INSERTED AS B ON A.ID_Document = B.ID_Document
														INNER JOIN DELETED AS C ON A.ID_Document = C.ID_Document
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

