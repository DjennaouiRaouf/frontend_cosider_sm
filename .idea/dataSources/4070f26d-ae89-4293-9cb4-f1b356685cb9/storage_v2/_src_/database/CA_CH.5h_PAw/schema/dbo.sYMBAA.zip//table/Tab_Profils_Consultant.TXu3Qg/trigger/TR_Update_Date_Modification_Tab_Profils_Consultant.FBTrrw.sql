CREATE TRIGGER TR_Update_Date_Modification_Tab_Profils_Consultant ON Tab_Profils_Consultant
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Profils_Consultant AS A
														INNER JOIN INSERTED AS B on CONCAT (A.ID_Consultant, A.Code_Profil) = CONCAT (B.ID_Consultant, B.Code_Profil)
														INNER JOIN DELETED AS C ON CONCAT (A.ID_Consultant, A.Code_Profil) = CONCAT (C.ID_Consultant, C.Code_Profil)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

