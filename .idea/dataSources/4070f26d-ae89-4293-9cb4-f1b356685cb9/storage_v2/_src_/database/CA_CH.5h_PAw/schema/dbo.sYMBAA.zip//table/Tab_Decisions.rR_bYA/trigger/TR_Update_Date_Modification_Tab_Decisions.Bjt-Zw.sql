CREATE TRIGGER TR_Update_Date_Modification_Tab_Decisions ON Tab_Decisions
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Decisions AS A
														INNER JOIN INSERTED AS B ON A.Code_Decision = B.Code_Decision
														INNER JOIN DELETED AS C ON A.Code_Decision = C.Code_Decision
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

