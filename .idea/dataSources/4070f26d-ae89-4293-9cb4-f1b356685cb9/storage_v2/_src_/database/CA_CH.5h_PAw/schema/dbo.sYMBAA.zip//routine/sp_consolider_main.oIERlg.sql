create   proc sp_consolider_main
as
BEGIN

	SET NOCOUNT ON;
	DECLARE @db_source NVARCHAR(max)
	DECLARE @db_niveau nvarchar(max) = 'filiale' 
	DECLARE @code varchar(max)
	DECLARE @getid CURSOR

	SET @getid = CURSOR FOR
	SELECT TRIM(' ' FROM name) AS name
	FROM   [CA].dbo.consolidate_db
	WHERE active = 1

	OPEN @getid
	FETCH NEXT
	FROM @getid INTO @db_source
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF EXISTS (SELECT 1 FROM sys.databases WHERE name = @db_source)
		begin
			set @code = @db_source
			if @db_niveau = 'filiale' and len(@db_source)=3
			begin
				set @code = @code + '_'
			end
			set @code = @code + '/'

			BEGIN TRY
				print '-------------------------------------------------------------------------------'
				print 'Debut de consolider de la base "'+@db_source+'"'

				exec ('sp_synch_global '''+@db_source+''','''+@code+''' ')

				print 'Fin de consolider de la base "'+@db_source+'"'
				print '-------------------------------------------------------------------------------'
				print ''
				update CA.dbo.consolidate_db set active=0 where name like @db_source
			END TRY
			BEGIN CATCH
				update CA.dbo.consolidate_db set active=1 where name like @db_source
				DECLARE @ErrorNumber NVARCHAR(max);
				DECLARE @ErrorMessage NVARCHAR(max);
				DECLARE @ErrorSeverity NVARCHAR(max);
				DECLARE @ErrorState NVARCHAR(max);
				DECLARE @ErrorProcedure NVARCHAR(max);

				SELECT
				@ErrorNumber    = ERROR_NUMBER(),
				@ErrorMessage   = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState     = ERROR_STATE(),
				@ErrorProcedure = ISNULL(ERROR_PROCEDURE(), 'N/A');

				print 'ErrorNumber : '+@ErrorNumber;
				print 'ErrorMessage : '+@ErrorMessage;
				print 'ErrorSeverity : '+@ErrorSeverity;
				print 'ErrorState : '+@ErrorState;
				if @ErrorProcedure = ''
					set @ErrorProcedure = 'N/A'
				print 'ErrorProcedure : '+@ErrorProcedure
		
				print ' ***** Echeck du consolider de la base "'+@db_source+'"'
				print '-------------------------------------------------------------------------------'
				print ''

			END CATCH
		END
		ELSE
			print ' ***** La base de donnees '+@db_source+' n''existe pas '

		FETCH NEXT
		FROM @getid INTO @db_source

	END
	CLOSE @getid
	DEALLOCATE @getid
	SET NOCOUNT OFF;
END
go

