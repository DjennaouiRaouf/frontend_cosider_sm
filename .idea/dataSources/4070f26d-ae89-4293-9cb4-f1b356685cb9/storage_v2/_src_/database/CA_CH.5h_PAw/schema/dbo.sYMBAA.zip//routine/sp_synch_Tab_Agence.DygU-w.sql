CREATE   procedure sp_synch_Tab_Agence @db_source varchar(max), @code varchar(max)
as
begin

DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agence] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agence] AS Source
ON (1=1 and ( Target.[Code_Agence] = ('''+@code+'''+Source.[Code_Agence] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Banque] = ('''+@code+'''+Source.[Code_Banque]),
Target.[Libelle_Agence] = Source.[Libelle_Agence],
Target.[Compte_Comptable] = Source.[Compte_Comptable],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Agence],
[Code_Banque],
[Libelle_Agence],
[Compte_Comptable],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Agence]),
('''+@code+'''+Source.[Code_Banque]),
Source.[Libelle_Agence],
Source.[Compte_Comptable],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

