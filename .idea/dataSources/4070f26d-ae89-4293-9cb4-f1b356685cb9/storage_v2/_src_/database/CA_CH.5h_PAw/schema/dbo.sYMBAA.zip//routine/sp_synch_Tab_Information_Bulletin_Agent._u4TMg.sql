
CREATE   procedure sp_synch_Tab_Information_Bulletin_Agent @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Information_Bulletin_Agent] AS Target
USING ['+@db_source+'].[dbo].[Tab_Information_Bulletin_Agent] AS Source
ON (1=1 and ( Target.[Code_Information_Bulletin_Agent] = ('''+@code+'''+Source.[Code_Information_Bulletin_Agent] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Nom] = Source.[Nom],
Target.[Prenom] = Source.[Prenom],
Target.[Mmaa] = Source.[Mmaa],
Target.[Classification] = Source.[Classification],
Target.[Code_Poste_Travail] = Source.[Code_Poste_Travail],
Target.[Code_Evenement_Agent] = ('''+@code+'''+Source.[Code_Evenement_Agent]),
Target.[Code_Agence] = ('''+@code+'''+Source.[Code_Agence]),
Target.[Mode_Paiement] = Source.[Mode_Paiement],
Target.[Num_Compte] = Source.[Num_Compte],
Target.[Date_Interval] = Source.[Date_Interval],
Target.[Code_Structure] = ('''+@code+'''+Source.[Code_Structure]),
Target.[Code_Statut_Horaire] = Source.[Code_Statut_Horaire],
Target.[Est_Archiver] = Source.[Est_Archiver],
Target.[Nbr_Enfant] = Source.[Nbr_Enfant],
Target.[Situation_Famille] = Source.[Situation_Famille],
Target.[Code_Caisse] = ('''+@code+'''+Source.[Code_Caisse]),
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Information_Bulletin_Agent],
[Matricule],
[Nom],
[Prenom],
[Mmaa],
[Classification],
[Code_Poste_Travail],
[Code_Evenement_Agent],
[Code_Agence],
[Mode_Paiement],
[Num_Compte],
[Date_Interval],
[Code_Structure],
[Code_Statut_Horaire],
[Est_Archiver],
[Nbr_Enfant],
[Situation_Famille],
[Code_Caisse],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Information_Bulletin_Agent]),
('''+@code+'''+Source.[Matricule]),
Source.[Nom],
Source.[Prenom],
Source.[Mmaa],
Source.[Classification],
Source.[Code_Poste_Travail],
('''+@code+'''+Source.[Code_Evenement_Agent]),
('''+@code+'''+Source.[Code_Agence]),
Source.[Mode_Paiement],
Source.[Num_Compte],
Source.[Date_Interval],
('''+@code+'''+Source.[Code_Structure]),
Source.[Code_Statut_Horaire],
Source.[Est_Archiver],
Source.[Nbr_Enfant],
Source.[Situation_Famille],
('''+@code+'''+Source.[Code_Caisse]),
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

