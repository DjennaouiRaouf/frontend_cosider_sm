----------------Fin----------------------------

--------Create Fonction Fct_Recuperer_Structure_Afficher_Dans_Bulletin--------------------
Create FUNCTION [dbo].[Fct_Recuperer_Structure_Afficher_Dans_Bulletin] (@Code_Structure Varchar(15)) 

returns   Varchar(255)

as 
begin


Declare @Libelle_Structure varchar(255)

set @Libelle_Structure=(select top(1) Libelle_Structure from [dbo].[Fct_Liste_Parent_Structure] (@Code_Structure)
where  Opt_Affichage is not null 
order by Niveau_Hierarchique desc)
return @Libelle_Structure
end
go

