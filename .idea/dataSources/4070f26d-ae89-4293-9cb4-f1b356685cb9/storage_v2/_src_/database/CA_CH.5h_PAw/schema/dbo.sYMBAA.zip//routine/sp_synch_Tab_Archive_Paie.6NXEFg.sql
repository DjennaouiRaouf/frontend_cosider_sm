CREATE   procedure sp_synch_Tab_Archive_Paie @db_source varchar(max), @code varchar(max)
as
begin

    DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Archive_Paie] AS Target
    USING ['+@db_source+'].[dbo].[Tab_Archive_Paie] AS Source
    ON (1=1 and Target.[Matricule] = ('''+@code+'''+Source.[Matricule]) and 
        (Target.[Code_Rubrique]=Source.[Code_Rubrique]) and 
        (Target.[Mmaa]=Source.[Mmaa]) and 
        (Target.[Mmaad]=Source.[Mmaad] or (Target.[Mmaad] is null and Source.[Mmaad] is null)))
    WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
    THEN
        UPDATE SET  Target.[Matricule]=('''+@code+'''+Source.[Matricule]),
        Target.[Code_Rubrique]=Source.[Code_Rubrique],
        Target.[Mmaa]=Source.[Mmaa],
        Target.[Mmaad]=Source.[Mmaad],
        Target.[Code_Information_Bulletin_Agent]=('''+@code+'''+Source.[Code_Information_Bulletin_Agent])
    WHEN NOT MATCHED 
    THEN
        INSERT (
        [Code_Information_Bulletin_Agent],
        [Matricule],
        [Code_Rubrique],
        [Mmaa],
        [Base],
        [Taux],
        [Mmaad],
        [Mmaaf],
        [Montant],
        [Observation],
        [Mode_Saisie],
        [User_ID],
        [Date_Modification]
        )
        VALUES (
                ('''+@code+'''+Source.[Code_Information_Bulletin_Agent]),
                ('''+@code+'''+Source.[Matricule]),
                Source.[Code_Rubrique],
                Source.[Mmaa],
                Source.[Base],
                Source.[Taux],
                Source.[Mmaad],
                Source.[Mmaaf],
                Source.[Montant],
                Source.[Observation],
                Source.[Mode_Saisie],
                case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
                Source.[Date_Modification]
        );'
    exec (@sql_interne)
end
go

