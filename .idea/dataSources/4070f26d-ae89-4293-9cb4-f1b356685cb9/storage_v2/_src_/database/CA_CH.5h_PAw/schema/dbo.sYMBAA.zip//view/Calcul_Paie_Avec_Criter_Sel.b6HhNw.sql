
-- VUE PAIE AVEC CRITER DE SELECTION

CREATE view [dbo].[Calcul_Paie_Avec_Criter_Sel] (Matricule,Code_Rubrique,Libelle_Rubrique,Base,Taux,Montant,Code_Structure,Code_Poste_Travail,Nom,Prenom,Code_Caisse,Est_Apprenti,
Code_Groupe,Code_Site,Code_Filiale,Code_Qualification,Code_Statut_Horaire,Type_Nature_Rub) as
SELECT a.Matricule,a.Code_Rubrique,e.Libelle_Rubrique,a.Base,a.Taux,a.Montant,b.Code_Structure,b.Code_Poste_Travail,c.nom,c.Prenom,
c.Code_Caisse,c.Est_Apprenti,b.Code_Groupe,b.Code_Site,b.Code_Filiale,d.Code_Qualification,b.Code_Statut_Horaire,CONCAT(e.Code_Type,e.Code_Nature) as Type_Nature_Rub
FROM Tab_Calcul_Paie as a

    CROSS APPLY(SELECT Libelle_Rubrique,Code_Type,Code_Nature FROM Tab_Plan_Rubriques where a.Code_Rubrique = Code_Rubrique) as e

    CROSS APPLY(SELECT TOP 1 Matricule,cl.Code_Groupe,ib.Code_Structure,st.Code_Site,si.Code_Filiale,Code_Poste_Travail,Code_Statut_Horaire FROM Tab_Information_Bulletin_Agent as ib
        LEFT join Tab_Classification  as cl on ib.Classification=cl.Classification
        INNER JOIN Tab_Structures as st on st.Code_Structure=ib.Code_Structure
        INNER JOIN Tab_Site as si on si.Code_site=st.Code_Site
    WHERE a.Matricule = Matricule AND ib.Est_Bloquer = 0 ORDER BY Code_Information_Bulletin_Agent DESC ) AS b

    CROSS APPLY (SELECT nom,Prenom,Code_Caisse,Est_Apprenti FROM Tab_Agent WHERE a.Matricule = Matricule) as c

    OUTER APPLY (SELECT Code_Qualification FROM Tab_Agent_Qualification WHERE Est_Principal = 1 and a.Matricule = Matricule AND Est_Bloquer = 0) as d
go

