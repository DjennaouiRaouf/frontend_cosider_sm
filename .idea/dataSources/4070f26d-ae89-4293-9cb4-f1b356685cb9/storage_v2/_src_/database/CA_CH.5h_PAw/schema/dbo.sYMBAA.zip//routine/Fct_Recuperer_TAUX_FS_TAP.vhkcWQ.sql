/****** Object:  UserDefinedFunction [dbo].[Fct_Recuperer_TAUX_FS_TAP]    ******/

Create FUNCTION [dbo].[Fct_Recuperer_TAUX_FS_TAP] (@Code_Filiale Varchar(15),@Mmaa date) 

returns   varchar(max)

as 
begin

declare @Date_Min Date
Declare @Date_Max Date
Declare @TAUX_FS_TAP varchar(max)


DECLARE @i int

DECLARE @Liste_TAUX_FS_TAP table(Ligne_TAUX_FS_TAP Int Identity(1,1) PRIMARY KEY,[Code_Filiale] Varchar(15),[Date_Debut] Date,[Date_Fin] Date,
[TAUX_FS] varchar(max),[Taux_TAP] varchar(max))

insert into @Liste_TAUX_FS_TAP ([Code_Filiale],[Date_Debut],[Date_Fin] ,[TAUX_FS],[Taux_TAP])
Select [Code_Filiale], [Date_Debut], [Date_Fin], [TAUX_FS], [Taux_TAP] from [dbo].[Tab_Taux_FS_TAP]
where [Code_Filiale]=@Code_Filiale order by [Date_Debut] asc;

WHILE Exists( SELECT [Code_Filiale] FROM @Liste_TAUX_FS_TAP)

Begin

select top 1  @i = Ligne_TAUX_FS_TAP,@Date_Min=[Date_Debut],@TAUX_FS_TAP=concat([TAUX_FS],',',[Taux_TAP]),@Date_Max=[Date_Fin] FROM @Liste_TAUX_FS_TAP
DELETE @Liste_TAUX_FS_TAP WHERE Ligne_TAUX_FS_TAP = @i


   if (@Mmaa between @Date_Min and @Date_Max) or (@Mmaa >= @Date_Min and @Date_Max is null)
   
   return @TAUX_FS_TAP

   else
  
  set @TAUX_FS_TAP=''
  
  end

return @TAUX_FS_TAP
end
go

