-----Creation FUNCTION [dbo].[Cte_Int] 
CREATE FUNCTION [dbo].[Cte_Int] (
@Code_Parametre varchar(10)
) returns int

as 
begin
declare @Int_Param Int
set @Int_Param=(SELECT CAST(REPLACE(Contenue_Parametre,';','') as Int) AS Param_Int FROM Tab_Constantes_Parametrables 
WHERE Code_Parametre = @Code_Parametre  AND  Est_Bloquer = 0)
RETURN @Int_Param
end;
go

