
CREATE   procedure sp_synch_Tab_Promotion_Agent @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Promotion_Agent] AS Target
USING ['+@db_source+'].[dbo].[Tab_Promotion_Agent] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule]) or (Target.[Matricule] is  null and Source.[Matricule] is null) ) and 
( Target.[Nbr_Promtion_Agent] = Source.[Nbr_Promtion_Agent] or (Target.[Nbr_Promtion_Agent] is  null and Source.[Nbr_Promtion_Agent] is null) ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Contrat] = ('''+@code+'''+Source.[Code_Contrat]),
Target.[Classification] = Source.[Classification],
Target.[Code_Poste_Travail] = Source.[Code_Poste_Travail],
Target.[Date_Classification] = Source.[Date_Classification],
Target.[Date_Fonction] = Source.[Date_Fonction],
Target.[Date_Fin_Fonction] = Source.[Date_Fin_Fonction],
Target.[Type_Promotion] = Source.[Type_Promotion],
Target.[Motif_Promotion] = Source.[Motif_Promotion],
Target.[Code_Decision] = ('''+@code+'''+Source.[Code_Decision]),
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Nbr_Promtion_Agent],
[Code_Contrat],
[Classification],
[Code_Poste_Travail],
[Date_Classification],
[Date_Fonction],
[Date_Fin_Fonction],
[Type_Promotion],
[Motif_Promotion],
[Code_Decision],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Nbr_Promtion_Agent],
('''+@code+'''+Source.[Code_Contrat]),
Source.[Classification],
Source.[Code_Poste_Travail],
Source.[Date_Classification],
Source.[Date_Fonction],
Source.[Date_Fin_Fonction],
Source.[Type_Promotion],
Source.[Motif_Promotion],
('''+@code+'''+Source.[Code_Decision]),
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

