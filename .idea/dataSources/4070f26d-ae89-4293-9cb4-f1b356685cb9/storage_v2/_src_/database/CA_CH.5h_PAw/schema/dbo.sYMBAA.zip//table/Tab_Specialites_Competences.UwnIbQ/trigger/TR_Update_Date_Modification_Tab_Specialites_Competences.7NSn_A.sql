CREATE TRIGGER TR_Update_Date_Modification_Tab_Specialites_Competences ON Tab_Specialites_Competences
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Specialites_Competences AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Specialite, A.Code_Competence) = CONCAT (B.Code_Specialite, B.Code_Competence)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Specialite, A.Code_Competence) = CONCAT (C.Code_Specialite, C.Code_Competence)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

