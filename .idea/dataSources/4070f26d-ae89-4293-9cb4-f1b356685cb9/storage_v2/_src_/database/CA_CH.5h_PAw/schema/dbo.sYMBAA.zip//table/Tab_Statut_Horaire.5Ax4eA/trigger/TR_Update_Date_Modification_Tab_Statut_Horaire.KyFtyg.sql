CREATE TRIGGER TR_Update_Date_Modification_Tab_Statut_Horaire ON Tab_Statut_Horaire
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Statut_Horaire AS A
														INNER JOIN INSERTED AS B ON A.Code_Statut_Horaire = B.Code_Statut_Horaire
														INNER JOIN DELETED AS C ON A.Code_Statut_Horaire = C.Code_Statut_Horaire
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

