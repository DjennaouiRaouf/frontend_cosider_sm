
/****** Object:  StoredProcedure [dbo].[Ordonnee_Colonne]    */

CREATE procedure [dbo].[Ordonnee_Colonne]
@table_name nvarchar(256),
@col_name nvarchar(256),
@Type_Donnees_Default NVARCHAR(MAX)
as
begin
DECLARE @Drop_Index NVARCHAR(MAX)
	DECLARE @Command NVARCHAR(MAX)
	DECLARE @Req_Ajout_Colonne NVARCHAR(MAX)
	DECLARE @Maj_Table NVARCHAR(MAX)
	DECLARE @Drop_Column NVARCHAR(MAX)
	DECLARE @Rename_Column NVARCHAR(MAX)
	DECLARE @Create_Index NVARCHAR(MAX)
	DECLARE @Name_Colonne varchar(MAX)
	DECLARE @Type_Donnee varchar(250)
	DECLARE @Name_Colonne_Ajouter varchar(100)
DECLARE @Liste_Colonne_Name table(Ligne_Colonne_Name Int Identity(1,1) PRIMARY KEY,Name_Colonne varchar(100))
insert into  @Liste_Colonne_Name( Name_Colonne ) SELECT value FROM STRING_SPLIT( @col_name, ',')
DECLARE @Liste_Type_Donnees_Default table(Ligne_Type_Donnees_Default Int Identity(1,1) PRIMARY KEY,Type_Donnees varchar(100))
insert into  @Liste_Type_Donnees_Default (Type_Donnees) SELECT value FROM STRING_SPLIT( @Type_Donnees_Default, ',')
DECLARE @i int
DECLARE @j int
	WHILE Exists( SELECT Name_Colonne FROM @Liste_Colonne_Name)
Begin
	    select top 1  @i = Ligne_Colonne_Name,@Name_Colonne=Name_Colonne FROM @Liste_Colonne_Name
		DELETE @Liste_Colonne_Name WHERE Ligne_Colonne_Name = @i
		
select top 1  @j =Ligne_Type_Donnees_Default,@Type_Donnee=Type_Donnees FROM @Liste_Type_Donnees_Default
		DELETE @Liste_Type_Donnees_Default WHERE Ligne_Type_Donnees_Default = @j
		set @Drop_Index='DROP INDEX IF EXISTS INDEX_'+@table_name+'_'+@Name_Colonne+' ON '+@table_name+' ;'
		exec sp_executesql @Drop_Index
		select @Command ='Alter Table ' +@table_name+ ' Drop Constraint [' + ( select d.name
			                                                                   from sys.tables t
				                                                               join sys.default_constraints d on d.parent_object_id = t.object_id
				                                                               join sys.columns c on c.object_id = t.object_id and c.column_id = d.parent_column_id					
			                                                                   where t.name = @table_name and c.name = @Name_Colonne) + ']'
		exec sp_executesql @Command
		set @Req_Ajout_Colonne='ALTER TABLE '+ @table_name +' ADD ['+ concat(@Name_Colonne,'_Copie')+'] '+@Type_Donnee+' ;'
		set @Maj_Table= 'Update '+@table_name + ' Set '+ @table_name+'.'+concat(@Name_Colonne,'_Copie')  +' = '+ @table_name+'.'+@Name_Colonne
		set @Drop_Column='ALTER TABLE '+ @table_name+ ' DROP COLUMN '+@Name_Colonne+' ;'
		set @Rename_Column='exec sp_rename  ''@table_name.@Name_Colonne_Copie'',''@Name_Colonne'',''COLUMN'' ;'
		set @Rename_Column=replace(@Rename_Column,'@table_name',@table_name)
		set @Rename_Column=replace(@Rename_Column,'@Name_Colonne',@Name_Colonne)
		set @Create_Index='CREATE INDEX [INDEX_'+@table_name+'_'+@Name_Colonne+'] ON ['+@table_name+'] (['+@Name_Colonne+']);'
		
		exec sp_executesql @Req_Ajout_Colonne
		exec sp_executesql @Maj_Table
		exec sp_executesql @Drop_Column
		exec sp_executesql @Drop_Index
		exec sp_executesql @Rename_Column
		exec sp_executesql @Create_Index
	end
end

go

