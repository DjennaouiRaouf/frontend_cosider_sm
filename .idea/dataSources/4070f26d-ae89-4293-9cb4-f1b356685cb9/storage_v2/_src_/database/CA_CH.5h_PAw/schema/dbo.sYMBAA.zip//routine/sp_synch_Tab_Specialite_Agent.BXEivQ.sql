
CREATE   procedure sp_synch_Tab_Specialite_Agent @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Specialite_Agent] AS Target
USING ['+@db_source+'].[dbo].[Tab_Specialite_Agent] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )) and ( Target.[Code_Specialite] = Source.[Code_Specialite] ) and ( Target.[Code_diplome] = Source.[Code_diplome] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Est_Principal] = Source.[Est_Principal],
Target.[Date_Diplome] = Source.[Date_Diplome],
Target.[Etablissement] = Source.[Etablissement],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Code_Specialite],
[Code_diplome],
[Est_Principal],
[Date_Diplome],
[Etablissement],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Code_Specialite],
Source.[Code_diplome],
Source.[Est_Principal],
Source.[Date_Diplome],
Source.[Etablissement],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

