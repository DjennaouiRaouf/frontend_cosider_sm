
CREATE   procedure sp_synch_Tab_Objectifs_Formation @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Objectifs_Formation] AS Target
USING ['+@db_source+'].[dbo].[Tab_Objectifs_Formation] AS Source
ON (1=1 and ( Target.[Code_Objectifs_Formation] = ('''+@code+'''+Source.[Code_Objectifs_Formation] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Formation] = ('''+@code+'''+Source.[Code_Formation]),
Target.[Libelle_Objectif] = Source.[Libelle_Objectif],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Objectifs_Formation],
[Code_Formation],
[Libelle_Objectif],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Objectifs_Formation]),
('''+@code+'''+Source.[Code_Formation]),
Source.[Libelle_Objectif],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

