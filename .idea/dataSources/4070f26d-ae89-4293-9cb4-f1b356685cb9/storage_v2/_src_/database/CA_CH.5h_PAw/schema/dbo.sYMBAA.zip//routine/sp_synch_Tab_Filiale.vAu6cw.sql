
CREATE   procedure sp_synch_Tab_Filiale @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Filiale] AS Target
USING ['+@db_source+'].[dbo].[Tab_Filiale] AS Source
ON (1=1 and ( Target.[Code_Filiale] = Source.[Code_Filiale] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Entreprise] = Source.[Code_Entreprise],
Target.[Libelle_Filiale] = Source.[Libelle_Filiale],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Filiale],
[Code_Entreprise],
[Libelle_Filiale],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
Source.[Code_Filiale],
Source.[Code_Entreprise],
Source.[Libelle_Filiale],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

