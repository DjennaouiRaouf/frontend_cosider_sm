
----les Trigger
/****** Object:  Trigger [dbo].[Desactivation_Mutuel]    Script Date: 06/03/2022 13:16:10 ******/

CREATE TRIGGER [dbo].[Desactivation_Mutuel] 
ON [dbo].[Tab_Evenement_Agent] 
AFTER UPDATE   
AS
  SET NOCOUNT ON;
    IF UPDATE (Avec_Deblocage_Provisoire_Paie) 
    BEGIN
      UPDATE [dbo].[Tab_Agent]
		SET [Avec_Mutuel] = 0
		 ,[Avec_Chomage_Intemperie] = 0
		 ,[Montant_Assurance_Groupe] = 0
		WHERE MATRICULE IN (SELECT Matricule FROM Tab_Evenement_Agent WHERE Avec_Deblocage_Provisoire_Paie = 1) 
    END  
go

