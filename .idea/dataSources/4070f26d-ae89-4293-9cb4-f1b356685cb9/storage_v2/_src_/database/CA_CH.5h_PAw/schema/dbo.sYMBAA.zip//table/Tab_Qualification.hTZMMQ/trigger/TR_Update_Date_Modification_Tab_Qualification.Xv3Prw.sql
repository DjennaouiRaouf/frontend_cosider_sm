CREATE TRIGGER TR_Update_Date_Modification_Tab_Qualification ON Tab_Qualification
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Qualification AS A
														INNER JOIN INSERTED AS B ON A.Code_Qualification = B.Code_Qualification
														INNER JOIN DELETED AS C ON A.Code_Qualification = C.Code_Qualification
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

