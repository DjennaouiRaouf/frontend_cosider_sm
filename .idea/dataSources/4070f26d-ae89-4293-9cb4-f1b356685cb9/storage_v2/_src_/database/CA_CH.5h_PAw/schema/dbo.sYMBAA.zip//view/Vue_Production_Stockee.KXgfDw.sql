create view Vue_Production_Stockee as (
select att.NT, att.Code_Site, att.Code_Tache, att.Qte_Attachee , prod.Qte_Produite , (prod.Qte_Produite-att.Qte_Attachee) as Ecart_Prod_Att ,
CASE WHEN prod.Qte_Produite - att.Qte_Attachee <> 0 THEN 1 ELSE 0 END AS Indicateur
 from Vue_Attachements_All att , Vue_Production_All prod
where att.NT = prod.NT and att.Code_Site = prod.Code_site and att.Code_Tache = prod.Code_Tache
)
go

