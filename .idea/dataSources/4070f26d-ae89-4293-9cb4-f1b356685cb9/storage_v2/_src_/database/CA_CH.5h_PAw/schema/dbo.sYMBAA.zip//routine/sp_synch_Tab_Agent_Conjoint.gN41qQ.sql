
CREATE   procedure sp_synch_Tab_Agent_Conjoint @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Conjoint] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Conjoint] AS Source
ON (1=1 and ( Target.[Code_Agent_Conjoint] = ('''+@code+'''+Source.[Code_Agent_Conjoint] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Nom_Conjoint] = Source.[Nom_Conjoint],
Target.[Prenom_Conjoint] = Source.[Prenom_Conjoint],
Target.[Date_Naissance_Conjoint] = Source.[Date_Naissance_Conjoint],
Target.[Code_Commune_Naissance] = Source.[Code_Commune_Naissance],
Target.[Date_Mariage] = Source.[Date_Mariage],
Target.[Date_Divorce] = Source.[Date_Divorce],
Target.[Date_Deces] = Source.[Date_Deces],
Target.[Avec_Emploi] = Source.[Avec_Emploi],
Target.[New_Situation_Famille] = Source.[New_Situation_Famille],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Agent_Conjoint],
[Matricule],
[Nom_Conjoint],
[Prenom_Conjoint],
[Date_Naissance_Conjoint],
[Code_Commune_Naissance],
[Date_Mariage],
[Date_Divorce],
[Date_Deces],
[Avec_Emploi],
[New_Situation_Famille],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Agent_Conjoint]),
('''+@code+'''+Source.[Matricule]),
Source.[Nom_Conjoint],
Source.[Prenom_Conjoint],
Source.[Date_Naissance_Conjoint],
Source.[Code_Commune_Naissance],
Source.[Date_Mariage],
Source.[Date_Divorce],
Source.[Date_Deces],
Source.[Avec_Emploi],
Source.[New_Situation_Famille],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

