CREATE TRIGGER TR_Update_Date_Modification_Tab_Evenement_Agent ON Tab_Evenement_Agent
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Evenement_Agent AS A
														INNER JOIN INSERTED AS B ON A.Code_Evenement_Agent = B.Code_Evenement_Agent
														INNER JOIN DELETED AS C ON A.Code_Evenement_Agent = C.Code_Evenement_Agent
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

