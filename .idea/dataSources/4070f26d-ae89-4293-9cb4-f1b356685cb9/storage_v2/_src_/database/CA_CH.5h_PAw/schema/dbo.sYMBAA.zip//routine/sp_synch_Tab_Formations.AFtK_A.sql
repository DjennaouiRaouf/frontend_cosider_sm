
CREATE   procedure sp_synch_Tab_Formations @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Formations] AS Target
USING ['+@db_source+'].[dbo].[Tab_Formations] AS Source
ON (1=1 and ( Target.[Code_Formation] = ('''+@code+'''+Source.[Code_Formation] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Specialite] = Source.[Code_Specialite],
Target.[Code_Type_Formation] = Source.[Code_Type_Formation],
Target.[Code_diplome] = Source.[Code_diplome],
Target.[Code_Mode_Formation] = Source.[Code_Mode_Formation],
Target.[Code_Organisme] = ('''+@code+'''+Source.[Code_Organisme]),
Target.[Niveau_Formation] = Source.[Niveau_Formation],
Target.[Libelle_Formation] = Source.[Libelle_Formation],
Target.[Date_Debut_Formation] = Source.[Date_Debut_Formation],
Target.[Date_Fin_Formation] = Source.[Date_Fin_Formation],
Target.[Nbr_Jours_Prevu] = Source.[Nbr_Jours_Prevu],
Target.[Nbr_Jour_Reel] = Source.[Nbr_Jour_Reel],
Target.[Etat_Formation] = Source.[Etat_Formation],
Target.[Observation] = Source.[Observation],
Target.[Lieu_Formation] = Source.[Lieu_Formation],
Target.[Nbr_Heures_Jour] = Source.[Nbr_Heures_Jour],
Target.[Matricule_Formateur_Interne] = ('''+@code+'''+Source.[Matricule_Formateur_Interne]),
Target.[Type_Organisme] = Source.[Type_Organisme],
Target.[Montant_Formation] = Source.[Montant_Formation],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Formation],
[Code_Specialite],
[Code_Type_Formation],
[Code_diplome],
[Code_Mode_Formation],
[Code_Organisme],
[Niveau_Formation],
[Libelle_Formation],
[Date_Debut_Formation],
[Date_Fin_Formation],
[Nbr_Jours_Prevu],
[Nbr_Jour_Reel],
[Etat_Formation],
[Observation],
[Lieu_Formation],
[Nbr_Heures_Jour],
[Matricule_Formateur_Interne],
[Type_Organisme],
[Montant_Formation],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Formation]),
Source.[Code_Specialite],
Source.[Code_Type_Formation],
Source.[Code_diplome],
Source.[Code_Mode_Formation],
('''+@code+'''+Source.[Code_Organisme]),
Source.[Niveau_Formation],
Source.[Libelle_Formation],
Source.[Date_Debut_Formation],
Source.[Date_Fin_Formation],
Source.[Nbr_Jours_Prevu],
Source.[Nbr_Jour_Reel],
Source.[Etat_Formation],
Source.[Observation],
Source.[Lieu_Formation],
Source.[Nbr_Heures_Jour],
('''+@code+'''+Source.[Matricule_Formateur_Interne]),
Source.[Type_Organisme],
Source.[Montant_Formation],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

