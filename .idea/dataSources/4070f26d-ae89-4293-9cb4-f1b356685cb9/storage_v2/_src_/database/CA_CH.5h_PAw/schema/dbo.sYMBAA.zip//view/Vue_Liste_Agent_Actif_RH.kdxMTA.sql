
-- Creation vue liste agent actif


CREATE VIEW [dbo].[Vue_Liste_Agent_Actif_RH]
	AS
	SELECT  A.Matricule,A.Nom,A.Prenom,C.Code_Poste_Travail,C.Libelle_Poste_Travail,F.Libelle_Structure,F.Code_Structure,F.Acronyme,D.Code_Type_Evenement,C.Classification FROM Tab_Agent AS A 
		OUTER APPLY (SELECT TOP (1) E.Libelle_Poste_Travail,E.Code_Poste_Travail,C.Classification FROM Tab_Promotion_Agent AS C LEFT JOIN Tab_Poste_Travail AS E ON E.Code_Poste_Travail = C.Code_Poste_Travail WHERE C.Matricule = A.Matricule	AND C.Est_Bloquer = 0 ORDER BY ID_Promotion_Agent DESC) AS C
		OUTER APPLY (SELECT Top (1) G.Code_Type_Evenement,G.Avec_Retour,G.Avec_Depart FROM Tab_Evenement_Agent AS D 
		OUTER APPLY (SELECT G.Code_Type_Evenement,G.Avec_Retour,G.Avec_Depart FROM  Tab_Evenement_RH AS G WHERE D.Code_Evenement = G.Code_Evenement ) AS G
		WHERE D.Matricule = A.Matricule AND D.Est_Bloquer = 0 ORDER BY Code_Evenement_Agent DESC) AS D
		OUTER APPLY (SELECT TOP 1 F.Code_Structure,E.Libelle_Structure,E.Acronyme FROM Tab_Affectation_Agent AS F
		OUTER APPLY (SELECT E.Libelle_Structure,E.Acronyme FROM Tab_Structures AS E WHERE F.Code_Structure = E.Code_Structure ) AS E
		WHERE A.Matricule = F.Matricule AND F.Est_Bloquer = 0 ORDER BY F.Nbr_Affectation DESC) AS F
		WHERE  D.Avec_Retour = 1 OR D.Avec_Depart = 0 OR D.Code_Type_Evenement IS NULL

go

