
--------Fonction Charges_Realiser_Par_Mois

CREATE function [dbo].[Fct_Charges_Realiser_Par_Mois] (@Date_Debut date,@Date_Fin date)  
returns table as return
(
SELECT Code_Filiale,Libelle_Filiale,Code_Division,Division,Code_Site,
isnull([01],0) as Realistion_Mensuel_MO ,isnull([02],0) as Realistion_Mensuel_MX,isnull([03],0) Realistion_Mensuel_ML,
isnull([04],0) Realistion_Mensuel_FG,isnull([05],0) as Realistion_Mensuel_ST

FROM
(
select g.Code_Filiale,g.Libelle_Filiale,g.Code_Division,g.Division,g.Code_Site,G.Code_Type_Charge,sum(g.Total_Charge_1) Total_Charge from
(select a.*,isnull(Total_Charge_1,0) as Total_Charge_1,b.Code_Type_Charge from (select * from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin)) as a
left join
(select Code_site,Code_Type_Charge,sum(valeur) Total_Charge_1 from Tab_Detaille_Charge 

where mmaa=@Date_Fin and Prevu_Realiser='R' and Type_Prestation=0 
group by Code_site,Code_Type_Charge) as b on a.Code_Site=b.Code_site

union all 

select a.*,Total_Charge_1,b.Code_Type_Charge from (select * from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin)) as a
left join
(select Code_site,Code_Type_Charge,sum(valeur)*-1 Total_Charge_1 from Tab_Detaille_Charge 

where mmaa=@Date_Fin and Prevu_Realiser='R' and Type_Prestation=1 
group by Code_site,Code_Type_Charge) as b on a.Code_Site=b.Code_site
 
union all 

 select a.*,Total_Charge_1,b.Code_Type_Charge from (select * from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin)) as a
left join
(select Recepteur,Code_Type_Charge,sum(valeur) Total_Charge_1 from Tab_Detaille_Charge 

where mmaa=@Date_Fin and Prevu_Realiser='R' and Type_Prestation=1 
group by Recepteur,Code_Type_Charge) as b on a.Code_Site=b.Recepteur

union all 

 select a.*,Total_Charge_1,b.Code_Type_Charge from (select * from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin)) as a
left join
(select Code_site,isnull(sum(Valeur),0) as Total_Charge_1,Code_Type_Charge from Tab_Sortie_Magasin_Vesrs_NT
where mmaa=@Date_Fin
group by Code_site,Code_Type_Charge) as b on a.Code_Site=b.Code_site) as g


where g.Code_Type_Charge is not null
group by Code_Filiale,Libelle_Filiale,Code_Division,Division,Code_Site,g.Code_Type_Charge

) AS TableSource
PIVOT
(
AVG(Total_Charge)
FOR Code_Type_Charge IN ([01], [02], [03], [04], [05])
) AS TableDePivot

)
go

