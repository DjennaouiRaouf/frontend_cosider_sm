CREATE TRIGGER TR_Update_Date_Modification_Tab_Specialite_Agent ON Tab_Specialite_Agent
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Specialite_Agent AS A
														INNER JOIN INSERTED AS B ON A.ID_Specialite_Agent = B.ID_Specialite_Agent
														INNER JOIN DELETED AS C ON A.ID_Specialite_Agent = C.ID_Specialite_Agent
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

