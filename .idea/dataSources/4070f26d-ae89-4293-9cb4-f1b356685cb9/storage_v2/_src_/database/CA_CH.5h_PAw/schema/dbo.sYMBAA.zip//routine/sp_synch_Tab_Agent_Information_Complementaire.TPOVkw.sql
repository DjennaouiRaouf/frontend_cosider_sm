
CREATE   procedure sp_synch_Tab_Agent_Information_Complementaire @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Information_Complementaire] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Information_Complementaire] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Etat_Sante] = Source.[Etat_Sante],
Target.[Service_National] = Source.[Service_National],
Target.[Date_Debut_Service] = Source.[Date_Debut_Service],
Target.[Date_Fin_Service] = Source.[Date_Fin_Service],
Target.[Num_Passport] = Source.[Num_Passport],
Target.[Date_Passport] = Source.[Date_Passport],
Target.[Num_Piece_Identite] = Source.[Num_Piece_Identite],
Target.[Date_Piece_Identite] = Source.[Date_Piece_Identite],
Target.[Num_Acte_Naissance] = Source.[Num_Acte_Naissance],
Target.[Num_Equipement] = Source.[Num_Equipement],
Target.[Num_Notification] = Source.[Num_Notification],
Target.[Date_Notification] = Source.[Date_Notification],
Target.[Pointure] = Source.[Pointure],
Target.[Taille_Veste] = Source.[Taille_Veste],
Target.[Taille_Pantalon] = Source.[Taille_Pantalon],
Target.[Taille_Tour_Tete] = Source.[Taille_Tour_Tete],
Target.[Nom_Papa] = Source.[Nom_Papa],
Target.[Prenom_Papa] = Source.[Prenom_Papa],
Target.[Nom_Mere] = Source.[Nom_Mere],
Target.[Prenom_Mere] = Source.[Prenom_Mere],
Target.[Code_Commune_PP] = Source.[Code_Commune_PP],
Target.[Code_Commune_PI] = Source.[Code_Commune_PI],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Etat_Sante],
[Service_National],
[Date_Debut_Service],
[Date_Fin_Service],
[Num_Passport],
[Date_Passport],
[Num_Piece_Identite],
[Date_Piece_Identite],
[Num_Acte_Naissance],
[Num_Equipement],
[Num_Notification],
[Date_Notification],
[Pointure],
[Taille_Veste],
[Taille_Pantalon],
[Taille_Tour_Tete],
[Nom_Papa],
[Prenom_Papa],
[Nom_Mere],
[Prenom_Mere],
[Code_Commune_PP],
[Code_Commune_PI],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Etat_Sante],
Source.[Service_National],
Source.[Date_Debut_Service],
Source.[Date_Fin_Service],
Source.[Num_Passport],
Source.[Date_Passport],
Source.[Num_Piece_Identite],
Source.[Date_Piece_Identite],
Source.[Num_Acte_Naissance],
Source.[Num_Equipement],
Source.[Num_Notification],
Source.[Date_Notification],
Source.[Pointure],
Source.[Taille_Veste],
Source.[Taille_Pantalon],
Source.[Taille_Tour_Tete],
Source.[Nom_Papa],
Source.[Prenom_Papa],
Source.[Nom_Mere],
Source.[Prenom_Mere],
Source.[Code_Commune_PP],
Source.[Code_Commune_PI],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

