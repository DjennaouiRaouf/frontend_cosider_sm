
-----Vue_Historique_Calcule_Paie] 

CREATE view [dbo].[Vue_Historique_Calcule_Paie] (Matricule,Code_Rubrique,Libelle_Rubrique,Avec_Nombre,Base,Taux,Montant,Retenue,Gains,Mmaa,Code_Structure)
as select a.matricule as Matricule,a.code_rubrique as Code_Rubrique,b.Libelle_Rubrique as Libelle_Rubrique,Avec_Nombre,a.Base as Base,
a.Taux as Taux,a.Montant as Montant,COALESCE(c.Retenue,0) as Retenue,
	COALESCE(d.gaine,0) as Gains,Mmaa as Mmaa,e.Code_Structure from  Tab_Archive_Paie as a

   cross apply (select code_rubrique,Libelle_Rubrique,CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature) AS Type_Nature_Rub, Sens,Avec_Nombre from 
	Tab_Plan_Rubriques where a.code_rubrique=code_rubrique and CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature)<>('CZ') and 
	CONCAT(Tab_Plan_Rubriques.Code_Type,Tab_Plan_Rubriques.Code_Nature)<>('CR')) as b

	outer apply(select sum(c.Montant) over (partition by c.Matricule ) as Retenue from Tab_Archive_Paie as c
	where (c.code_rubrique=a.code_rubrique) and (c.Mmaad=a.Mmaad or (a.Mmaad is null and c.Mmaad is null)) and b.Type_Nature_Rub<>('CZ') and
	b.Type_Nature_Rub<>('CR') and a.Matricule=c.Matricule and b.Sens<0 and a.mmaa=mmaa) as c 

	outer apply(select  sum(d.Montant) over (partition by d.Matricule ) as gaine from Tab_Archive_Paie as d
	where (d.code_rubrique=a.code_rubrique) and (d.Mmaad=a.Mmaad or (a.Mmaad is null and d.Mmaad is null)) and b.Type_Nature_Rub<>('CZ') and
	b.Type_Nature_Rub<>('CR') and a.Matricule=d.Matricule and b.Sens>0 and a.mmaa=mmaa) as d

	cross apply (select distinct Code_Structure from Tab_Information_Bulletin_Agent
    where Code_Information_Bulletin_Agent=a.Code_Information_Bulletin_Agent) as e

go

