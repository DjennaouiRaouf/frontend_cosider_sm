
CREATE   procedure sp_synch_Tab_Decisions @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Decisions] AS Target
USING ['+@db_source+'].[dbo].[Tab_Decisions] AS Source
ON (1=1 and ( Target.[Code_Decision] = ('''+@code+'''+Source.[Code_Decision] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Ref_Decision] = Source.[Ref_Decision],
Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Date_Decision] = Source.[Date_Decision],
Target.[Code_Structure_Emettrice_Doc] = ('''+@code+'''+Source.[Code_Structure_Emettrice_Doc]),
Target.[Matricule_Responsable_Legalisation] = ('''+@code+'''+Source.[Matricule_Responsable_Legalisation]),
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Decision],
[Ref_Decision],
[Matricule],
[Date_Decision],
[Code_Structure_Emettrice_Doc],
[Matricule_Responsable_Legalisation],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Decision]),
Source.[Ref_Decision],
('''+@code+'''+Source.[Matricule]),
Source.[Date_Decision],
('''+@code+'''+Source.[Code_Structure_Emettrice_Doc]),
('''+@code+'''+Source.[Matricule_Responsable_Legalisation]),
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

