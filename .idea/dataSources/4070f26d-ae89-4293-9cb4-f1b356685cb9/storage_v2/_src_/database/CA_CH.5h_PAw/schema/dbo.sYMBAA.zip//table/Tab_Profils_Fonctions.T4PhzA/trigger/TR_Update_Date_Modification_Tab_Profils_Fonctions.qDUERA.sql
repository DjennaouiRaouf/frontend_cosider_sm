CREATE TRIGGER TR_Update_Date_Modification_Tab_Profils_Fonctions ON Tab_Profils_Fonctions
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Profils_Fonctions AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Profil, A.Code_Fonction) = CONCAT (B.Code_Profil, B.Code_Fonction)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Profil, A.Code_Fonction) = CONCAT (C.Code_Profil, C.Code_Fonction)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

