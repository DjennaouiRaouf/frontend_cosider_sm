-- FONCTION Fct_301_BIS

CREATE function [dbo].[Fct_301_BIS] (@Annee int) 
returns table as return
(
select a.matricule,a.nom,a.prenom,b.Mmaa,
sum(b.Base) over (partition by a.Matricule ) as BaseAnnuel_IRG_Bareme,
sum(b.Montant*-1) over (partition by a.Matricule ) as RetenueAnnuel_IRG_Bareme,

sum(b.Base_IRG10)over (partition by a.Matricule ) as BaseAnnuel_IRG_10_Pourcent,
sum(b.Montant_Retenue_10*-1) over (partition by a.Matricule ) as RetenueAnnuel_IRG_10_Pourcent,

b.Base,b.Montant*-1 AS Montant,c.Situation_Famille,c.Libelle_poste_travail from Tab_Agent as a

 cross apply
    (select IIF(f.Matricule is null,g.Matricule,f.Matricule) as Matricule,IIF(f.Mmaa is null,g.Mmaa,f.Mmaa) as Mmaa,
	isnull(f.Base,0) Base,isnull(f.Montant,0) Montant,isnull(g.base,0) as Base_IRG10, isnull(g.Montant,0) as Montant_Retenue_10 from
    
	(select matricule,Mmaa,round(sum(Base),2) as base,round(sum(Montant),2) as Montant from Tab_Archive_Paie 
    where  year(Mmaa) = @Annee and  code_rubrique IN (SELECT DISTINCT Rubrique_IRG FROM Tab_Plan_Rubriques where Mode_Calcule_IRG=1) 
     GROUP BY Matricule,Mmaa) as f Full outer join

	 (select matricule,Mmaa,round(sum(Base),2) as base,round(sum(Montant),2) as Montant from Tab_Archive_Paie 
    where year(Mmaa) = @Annee and code_rubrique IN (SELECT DISTINCT Rubrique_IRG FROM Tab_Plan_Rubriques where Mode_Calcule_IRG=2) 
     GROUP BY Matricule,Mmaa) as g on f.Matricule=g.Matricule and f.Mmaa=g.Mmaa

    
	) as b

    cross apply (select top 1 pt.Libelle_poste_travail,ib.Code_Information_Bulletin_Agent,ib.Situation_Famille,ib.Code_Poste_Travail
     from Tab_Information_Bulletin_Agent as ib,Tab_Poste_Travail as pt
    where a.Matricule=ib.Matricule and ib.Code_Poste_Travail=pt.Code_Poste_Travail AND ib.Est_Bloquer = 0
    order by Code_Information_Bulletin_Agent desc) as c
    
    where a.Matricule=b.Matricule
     
)

go

