
CREATE   procedure sp_synch_Tab_Agent_Contrat @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Contrat] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Contrat] AS Source
ON (1=1 and ( Target.[Code_Contrat] = ('''+@code+'''+Source.[Code_Contrat] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Ref_Contrat] = Source.[Ref_Contrat],
Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Nbr_Contrat] = Source.[Nbr_Contrat],
Target.[Code_Statut_Horaire] = Source.[Code_Statut_Horaire],
Target.[Date_Debut_Contrat] = Source.[Date_Debut_Contrat],
Target.[Date_Fin_Contrat] = Source.[Date_Fin_Contrat],
Target.[Duree_Essai] = Source.[Duree_Essai],
Target.[Code_Type_Contrat] = Source.[Code_Type_Contrat],
Target.[Situation_Contrat] = Source.[Situation_Contrat],
Target.[Observation] = Source.[Observation],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Contrat],
[Ref_Contrat],
[Matricule],
[Nbr_Contrat],
[Code_Statut_Horaire],
[Date_Debut_Contrat],
[Date_Fin_Contrat],
[Duree_Essai],
[Code_Type_Contrat],
[Situation_Contrat],
[Observation],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Contrat]),
Source.[Ref_Contrat],
('''+@code+'''+Source.[Matricule]),
Source.[Nbr_Contrat],
Source.[Code_Statut_Horaire],
Source.[Date_Debut_Contrat],
Source.[Date_Fin_Contrat],
Source.[Duree_Essai],
Source.[Code_Type_Contrat],
Source.[Situation_Contrat],
Source.[Observation],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

