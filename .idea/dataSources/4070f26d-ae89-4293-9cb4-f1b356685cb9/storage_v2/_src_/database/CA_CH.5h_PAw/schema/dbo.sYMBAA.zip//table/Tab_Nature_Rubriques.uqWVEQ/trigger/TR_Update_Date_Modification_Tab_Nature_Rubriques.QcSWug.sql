CREATE TRIGGER TR_Update_Date_Modification_Tab_Nature_Rubriques ON Tab_Nature_Rubriques
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Nature_Rubriques AS A
														INNER JOIN INSERTED AS B ON A.Code_Nature = B.Code_Nature
														INNER JOIN DELETED AS C ON A.Code_Nature = C.Code_Nature
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

