CREATE TRIGGER TR_Update_Date_Modification_Tab_Apprenti_Maitre_Apprenti ON Tab_Apprenti_Maitre_Apprenti
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Apprenti_Maitre_Apprenti AS A
														INNER JOIN INSERTED AS B ON A.ID_Apprenti_Maitre_Appr = B.ID_Apprenti_Maitre_Appr
														INNER JOIN DELETED AS C ON A.ID_Apprenti_Maitre_Appr = C.ID_Apprenti_Maitre_Appr
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

