CREATE TRIGGER TR_Update_Date_Modification_Tab_Rubriques_Impactees_Par_Evenement_RH ON Tab_Rubriques_Impactees_Par_Evenement_RH
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Rubriques_Impactees_Par_Evenement_RH AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Evenement, A.Code_Rubrique) = CONCAT (B.Code_Evenement, B.Code_Rubrique)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Evenement, A.Code_Rubrique) = CONCAT (C.Code_Evenement, C.Code_Rubrique)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

