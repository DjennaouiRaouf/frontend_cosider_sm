CREATE TRIGGER TR_Update_Date_Modification_Tab_Formation_Competence ON Tab_Formation_Competence
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Formation_Competence AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Competence, A.Code_Formation) = CONCAT (B.Code_Competence, B.Code_Formation)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Competence, A.Code_Formation) = CONCAT (C.Code_Competence, C.Code_Formation)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

