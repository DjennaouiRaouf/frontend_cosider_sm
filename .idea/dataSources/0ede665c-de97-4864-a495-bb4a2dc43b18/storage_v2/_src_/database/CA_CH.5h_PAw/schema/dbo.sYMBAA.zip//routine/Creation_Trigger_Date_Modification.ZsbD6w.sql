---Fin Procedure sp_fkeys_Name

----PROCEDURE Creation_Trigger_Date_Modification

CREATE PROCEDURE Creation_Trigger_Date_Modification

as 

begin

DECLARE @TableName as NVARCHAR(250)
DECLARE @Nbr_Column as INT

DECLARE Table_Name_Cursor CURSOR FOR  

SELECT A.TABLE_NAME, B.Nbr_Column
FROM   INFORMATION_SCHEMA.TABLES AS A
OUTER APPLY ( SELECT   
          COUNT( COL_NAME(IC.OBJECT_ID,IC.COLUMN_ID) ) AS Nbr_Column
FROM       SYS.INDEXES  X 
INNER JOIN SYS.INDEX_COLUMNS  IC 
        ON X.OBJECT_ID = IC.OBJECT_ID
       AND X.INDEX_ID = IC.INDEX_ID
WHERE      X.IS_PRIMARY_KEY = 1
  AND      OBJECT_NAME(IC.OBJECT_ID) =  A.TABLE_NAME ) AS B
WHERE A.Table_Type = 'BASE TABLE' ;  

OPEN Table_Name_Cursor;  
FETCH NEXT FROM Table_Name_Cursor INTO @TableName, @Nbr_Column; 
 
WHILE @@FETCH_STATUS = 0  
   BEGIN  

	IF @TableName <> 'Tab_Archive_Paie'
		BEGIN

		   IF COL_LENGTH( @TableName,'Date_Modification') IS NOT NULL
				BEGIN
				-- La colonne Date de modification Existe creation du trigger
						IF NOT EXISTS (select * from sys.objects where schema_id=SCHEMA_ID('dbo') AND type='TR' and name='TR_Update_Date_Modification_'+@TableName)
							BEGIN

							   IF @Nbr_Column > 1 
								BEGIN
								
									DECLARE @Resultat_Alias_A nvarchar(500) = NULL;
									DECLARE @Resultat_Alias_B nvarchar(500) = NULL;
									DECLARE @Resultat_Alias_C nvarchar(500) = NULL;

			
									SELECT  @Resultat_Alias_A = COALESCE(@Resultat_Alias_A+', ','') +'A.'+COL_NAME(IC.OBJECT_ID,IC.COLUMN_ID),
											@Resultat_Alias_B = COALESCE(@Resultat_Alias_B+', ','') +'B.'+COL_NAME(IC.OBJECT_ID,IC.COLUMN_ID),
											@Resultat_Alias_C = COALESCE(@Resultat_Alias_C+', ','') +'C.'+COL_NAME(IC.OBJECT_ID,IC.COLUMN_ID)

									FROM SYS.INDEXES  X 
										INNER JOIN SYS.INDEX_COLUMNS  IC 
												ON X.OBJECT_ID = IC.OBJECT_ID
											   AND X.INDEX_ID = IC.INDEX_ID
										WHERE      X.IS_PRIMARY_KEY = 1
										 AND      OBJECT_NAME(IC.OBJECT_ID) = @TableName ;

										SET @Resultat_Alias_A = 'CONCAT ('+@Resultat_Alias_A+')';
										SET @Resultat_Alias_B = 'CONCAT ('+@Resultat_Alias_B+')';
										SET @Resultat_Alias_C = 'CONCAT ('+@Resultat_Alias_C+')';

										EXECUTE ('CREATE TRIGGER TR_Update_Date_Modification_'+@TableName+' ON '+@TableName+'
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														'+@TableName+' AS A
														INNER JOIN INSERTED AS B on '+@Resultat_Alias_A+' = '+@Resultat_Alias_B+'
														INNER JOIN DELETED AS C ON '+@Resultat_Alias_A+' = '+@Resultat_Alias_C+'
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;');
								
								END;

							ELSE IF @Nbr_Column = 1

								BEGIN

									DECLARE @NomColumn as nvarchar(100)

									SET @NomColumn = ( SELECT   
															COL_NAME(IC.OBJECT_ID,IC.COLUMN_ID) 
														FROM       SYS.INDEXES  X 
															INNER JOIN SYS.INDEX_COLUMNS  IC 
																		ON X.OBJECT_ID = IC.OBJECT_ID
																	   AND X.INDEX_ID = IC.INDEX_ID
														WHERE      X.IS_PRIMARY_KEY = 1  AND      OBJECT_NAME(IC.OBJECT_ID) = @TableName );


									EXECUTE ('CREATE TRIGGER TR_Update_Date_Modification_'+@TableName+' ON '+@TableName+'
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														'+@TableName+' AS A
														INNER JOIN INSERTED AS B ON A.'+@NomColumn+' = B.'+@NomColumn+'
														INNER JOIN DELETED AS C ON A.'+@NomColumn+' = C.'+@NomColumn+'
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;');

								END;

							END

						/*ELSE -- A SUPPRIMER APRES VERIFICATION
							BEGIN
								EXECUTE ('DROP TRIGGER TR_Update_Date_Modification_'+@TableName);
							END;*/
				END;

			END; -- FIN VERIFICATION TABLE ARCHIVE PAIE

      FETCH NEXT FROM Table_Name_Cursor INTO @TableName, @Nbr_Column;   
   END;  
CLOSE Table_Name_Cursor;  
DEALLOCATE Table_Name_Cursor;  
end
go

