CREATE TRIGGER TR_Update_Date_Modification_Tab_Rubriques_Evalution_Performance ON Tab_Rubriques_Evalution_Performance
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Rubriques_Evalution_Performance AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Performance_Agent, A.Code_Rubrique_Performance) = CONCAT (B.Code_Performance_Agent, B.Code_Rubrique_Performance)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Performance_Agent, A.Code_Rubrique_Performance) = CONCAT (C.Code_Performance_Agent, C.Code_Rubrique_Performance)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

