CREATE TRIGGER TR_Update_Date_Modification_Tab_Agent_Competences ON Tab_Agent_Competences
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Agent_Competences AS A
														INNER JOIN INSERTED AS B ON A.ID_Agent_Competence = B.ID_Agent_Competence
														INNER JOIN DELETED AS C ON A.ID_Agent_Competence = C.ID_Agent_Competence
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

