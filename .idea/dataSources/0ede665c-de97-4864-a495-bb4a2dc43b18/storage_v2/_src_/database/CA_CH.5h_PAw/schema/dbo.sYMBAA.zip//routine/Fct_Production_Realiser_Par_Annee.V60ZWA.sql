
-- FONCTION Production_Realiser_Par_Annee

CREATE function [dbo].[Fct_Production_Realiser_Par_Annee] (@Date_Debut date,@Date_Fin date) 
returns table as return
(
SELECT 
 a.*,(isnull(b.Total_Annuel_Realise_prod_propre,0)-isnull(d.Total_Annuel_Realise_prod_ST,0)) as Total_Annuel_Realise_prod_propre,
 isnull(c.Total_Annuel_Realise_prod_preste_Interne,0) as Total_Annuel_Realise_prod_preste_Interne,
  isnull(c.Total_Annuel_Realise_prod_preste_Externe,0) as Total_Annuel_Realise_prod_preste_Externe,
 isnull(d.Total_Annuel_Realise_prod_ST,0) as Total_Annuel_Realise_prod_ST FROM [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a
left join
(select Code_site,sum(Valeur_1+Valeur_2+Valeur_3)  Total_Annuel_Realise_prod_propre from Tab_Production 
where Code_Type_Production='01' and Prevu_Realiser='R' and (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as b on a.Code_site=b.Code_site 

left join

(select a.Code_site, 
(isnull(b.Total_Annuel_Realise_prod_preste1,0)+isnull(c.Total_Annuel_Realise_prod_preste2,0)+isnull(f.Total_Annuel_Realise_prod_preste3,0)) as Total_Annuel_Realise_prod_preste_Interne,
(isnull(d.Total_Annuel_Realise_prod_preste_Externe1,0)+isnull(e.Total_Annuel_Realise_prod_preste_Externe2,0)) as Total_Annuel_Realise_prod_preste_Externe
from [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a

left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Annuel_Realise_prod_preste1 from Tab_Production 
where Code_Type_Production='02' and Prevu_Realiser='R' and Type_Prestation in (1,2) and (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as b on a.Code_site=b.Code_site

left join
(select Recepteur,isnull(sum(Valeur_1)*-1,0) as Total_Annuel_Realise_prod_preste2 from Tab_Production 
where Code_Type_Production='02' and Prevu_Realiser='R' and Type_Prestation=1 and (mmaa between @Date_Debut and @Date_Fin)
group by Recepteur) as c on a.Code_site=c.Recepteur

left join
(select Code_site,isnull(sum(Valeur),0) as Total_Annuel_Realise_prod_preste3 from Tab_Detaille_Charge 
where Prevu_Realiser='R' and Type_Prestation=2 and (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as f on a.Code_site=f.Code_site

left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Annuel_Realise_prod_preste_Externe1 from Tab_Production 
where Code_Type_Production='02' and Prevu_Realiser='R' and Type_Prestation=3 and (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as d on a.Code_site=d.Code_site

left join
(select Code_site,isnull(sum(Valeur),0) as Total_Annuel_Realise_prod_preste_Externe2 from Tab_Detaille_Charge 
where Prevu_Realiser='R' and Type_Prestation=3 and (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as e on a.Code_site=e.Code_site

)  as c on a.Code_site=c.Code_site


left join

(select a.Code_site,sum(Valeur_1) as Total_Annuel_Realise_prod_ST from Tab_Production as a
where Code_Type_Production='03' and Prevu_Realiser='R' and (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as d on a.Code_site=d.Code_site
     
)
go

