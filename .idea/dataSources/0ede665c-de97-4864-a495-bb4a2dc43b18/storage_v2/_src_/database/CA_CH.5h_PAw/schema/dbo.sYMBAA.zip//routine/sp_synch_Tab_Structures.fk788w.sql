
CREATE   procedure sp_synch_Tab_Structures @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Structures] AS Target
USING ['+@db_source+'].[dbo].[Tab_Structures] AS Source
ON (1=1 and ( Target.[Code_Structure] = ('''+@code+'''+Source.[Code_Structure] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Site] = Source.[Code_Site],
Target.[Libelle_Structure] = Source.[Libelle_Structure],
Target.[Nbr_Agent_Prevue] = Source.[Nbr_Agent_Prevue],
Target.[Acronyme] = Source.[Acronyme],
Target.[Code_Parent] = ('''+@code+'''+Source.[Code_Parent]),
Target.[Niveau_Hierarchique] = Source.[Niveau_Hierarchique],
Target.[Code_Famille_Structure] = Source.[Code_Famille_Structure],
Target.[Est_Structure_Chantier] = Source.[Est_Structure_Chantier],
Target.[Est_Atelier_Production] = Source.[Est_Atelier_Production],
Target.[Avec_Site_Recepteur] = Source.[Avec_Site_Recepteur],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Structure],
[Code_Site],
[Libelle_Structure],
[Nbr_Agent_Prevue],
[Acronyme],
[Code_Parent],
[Niveau_Hierarchique],
[Code_Famille_Structure],
[Est_Structure_Chantier],
[Est_Atelier_Production],
[Avec_Site_Recepteur],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Structure]),
Source.[Code_Site],
Source.[Libelle_Structure],
Source.[Nbr_Agent_Prevue],
Source.[Acronyme],
('''+@code+'''+Source.[Code_Parent]),
Source.[Niveau_Hierarchique],
Source.[Code_Famille_Structure],
Source.[Est_Structure_Chantier],
Source.[Est_Atelier_Production],
Source.[Avec_Site_Recepteur],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

