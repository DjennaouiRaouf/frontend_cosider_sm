
CREATE   procedure sp_synch_Tab_Reliquat_Conge_Annuel @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Reliquat_Conge_Annuel] AS Target
USING ['+@db_source+'].[dbo].[Tab_Reliquat_Conge_Annuel] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )) and ( Target.[Exercice] = Source.[Exercice] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Nbr_Jours_Dus] = Source.[Nbr_Jours_Dus],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],
[Exercice],
[Nbr_Jours_Dus],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),
Source.[Exercice],
Source.[Nbr_Jours_Dus],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

