
CREATE   procedure sp_synch_Tab_Evenement_Agent @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Evenement_Agent] AS Target
USING ['+@db_source+'].[dbo].[Tab_Evenement_Agent] AS Source
ON (1=1 and ( Target.[Code_Evenement_Agent] = ('''+@code+'''+Source.[Code_Evenement_Agent] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Code_Evenement] = Source.[Code_Evenement],
Target.[Date_Evenement] = Source.[Date_Evenement],
Target.[Motif_Evenement] = Source.[Motif_Evenement],
Target.[Avec_Blocage_Paie] = Source.[Avec_Blocage_Paie],
Target.[Avec_Deblocage_Provisoire_Paie] = Source.[Avec_Deblocage_Provisoire_Paie],
Target.[Date_Retour_Reel] = Source.[Date_Retour_Reel],
Target.[Date_Fin_Evenement_Prevu] = Source.[Date_Fin_Evenement_Prevu],
Target.[Nbr_Heures] = Source.[Nbr_Heures],
Target.[Nbr_Jours] = Source.[Nbr_Jours],
Target.[Code_Decision] = ('''+@code+'''+Source.[Code_Decision]),
Target.[Est_Archiver] = Source.[Est_Archiver],
Target.[Est_Correction_Evenement] = Source.[Est_Correction_Evenement],
Target.[Code_Parent] = ('''+@code+'''+Source.[Code_Parent]),
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Evenement_Agent],
[Matricule],
[Code_Evenement],
[Date_Evenement],
[Motif_Evenement],
[Avec_Blocage_Paie],
[Avec_Deblocage_Provisoire_Paie],
[Date_Retour_Reel],
[Date_Fin_Evenement_Prevu],
[Nbr_Heures],
[Nbr_Jours],
[Code_Decision],
[Est_Archiver],
[Est_Correction_Evenement],
[Code_Parent],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Evenement_Agent]),
('''+@code+'''+Source.[Matricule]),
Source.[Code_Evenement],
Source.[Date_Evenement],
Source.[Motif_Evenement],
Source.[Avec_Blocage_Paie],
Source.[Avec_Deblocage_Provisoire_Paie],
Source.[Date_Retour_Reel],
Source.[Date_Fin_Evenement_Prevu],
Source.[Nbr_Heures],
Source.[Nbr_Jours],
('''+@code+'''+Source.[Code_Decision]),
Source.[Est_Archiver],
Source.[Est_Correction_Evenement],
('''+@code+'''+Source.[Code_Parent]),
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

