CREATE TRIGGER TR_Update_Date_Modification_Tab_Classification ON Tab_Classification
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Classification AS A
														INNER JOIN INSERTED AS B ON A.Classification = B.Classification
														INNER JOIN DELETED AS C ON A.Classification = C.Classification
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

