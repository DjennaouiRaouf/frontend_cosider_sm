CREATE TRIGGER TR_Update_Date_Modification_Tab_Modules_Constantes ON Tab_Modules_Constantes
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Modules_Constantes AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Module, A.Code_Parametre) = CONCAT (B.Code_Module, B.Code_Parametre)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Module, A.Code_Parametre) = CONCAT (C.Code_Module, C.Code_Parametre)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

