CREATE TRIGGER TR_Update_Date_Modification_Tab_Historique_Impact_Evenement_Paie ON Tab_Historique_Impact_Evenement_Paie
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Historique_Impact_Evenement_Paie AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Evenement_Agent, A.Mmaa, A.Code_Rubrique) = CONCAT (B.Code_Evenement_Agent, B.Mmaa, B.Code_Rubrique)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Evenement_Agent, A.Mmaa, A.Code_Rubrique) = CONCAT (C.Code_Evenement_Agent, C.Mmaa, C.Code_Rubrique)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

