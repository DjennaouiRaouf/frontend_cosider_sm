---------------Fin----------------------------------------------------

--------Create Fonction Fct_Liste_Parent_Structure--------------------
Create FUNCTION [dbo].[Fct_Liste_Parent_Structure] (@Code_Structure varchar(15)) 
returns table as return
(
WITH cte AS (
	SELECT Code_Structure,Libelle_Structure,Code_Parent, Niveau_Hierarchique,Est_Bloquer,Code_Site,Opt_Affichage
	FROM Tab_Structures ST
	WHERE ST.Code_Structure = @Code_Structure and ST.Est_Bloquer = 0 

	UNION ALL

	SELECT ST.Code_Structure,ST.Libelle_Structure,ST.Code_Parent, st.Niveau_Hierarchique,ST.Est_Bloquer,ST.Code_Site,ST.Opt_Affichage
	FROM Tab_Structures ST
	JOIN cte ON cte.Code_Parent = ST.Code_Structure 
)
SELECT * FROM cte
WHERE cte.Est_Bloquer = 0

)
go

