CREATE TRIGGER TR_Update_Date_Modification_Tab_Domaine ON Tab_Domaine
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Domaine AS A
														INNER JOIN INSERTED AS B ON A.Code_Domaine = B.Code_Domaine
														INNER JOIN DELETED AS C ON A.Code_Domaine = C.Code_Domaine
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

