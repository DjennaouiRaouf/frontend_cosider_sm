---Fin de suppression


-----Creation Fonction de recuperation Numero adherent EMPOYEUR---------

Create FUNCTION Fct_Recuperer_Num_Adherent (@Code_Casse Varchar(15),@Mmaa date) 

returns   Varchar(20)

as 
begin

declare @Date_Min Date
Declare @Date_Max Date
Declare @Num_Employeur varchar(20)


DECLARE @i int

DECLARE @Liste_Caisse table(Ligne_Casse Int Identity(1,1) PRIMARY KEY,[Code_Caisse] Varchar(15),[Mmaa] Date,[Num_SS_Employeur] varchar(20),
[Date_Interval] Date)

insert into @Liste_Caisse ([Code_Caisse],[Mmaa],[Num_SS_Employeur],[Date_Interval])
Select [Code_Caisse],[Mmaa],[Num_SS_Employeur],[Date_Interval] from [dbo].[Tab_Historique_Information_Caisse_Cotisation] 
where [Code_Caisse]=@Code_Casse order by [Mmaa] asc;

WHILE Exists( SELECT [Code_Caisse] FROM @Liste_Caisse)

Begin

select top 1  @i = Ligne_Casse,@Date_Min=[Mmaa],@Num_Employeur=[Num_SS_Employeur],@Date_Max=[Date_Interval] FROM @Liste_Caisse
DELETE @Liste_Caisse WHERE Ligne_Casse = @i


   if (@Mmaa between @Date_Min and @Date_Max) or (@Mmaa >= @Date_Min and @Date_Max is null)
   
   return @Num_Employeur

   else
  
  set @Num_Employeur=''
  
  end

return @Num_Employeur
end
go

