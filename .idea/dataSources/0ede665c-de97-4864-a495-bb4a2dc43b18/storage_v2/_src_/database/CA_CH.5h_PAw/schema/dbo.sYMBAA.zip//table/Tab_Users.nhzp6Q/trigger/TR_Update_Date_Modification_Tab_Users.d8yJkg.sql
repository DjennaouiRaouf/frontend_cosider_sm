CREATE TRIGGER TR_Update_Date_Modification_Tab_Users ON Tab_Users
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Users AS A
														INNER JOIN INSERTED AS B ON A.User_ID = B.User_ID
														INNER JOIN DELETED AS C ON A.User_ID = C.User_ID
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

