
CREATE   procedure sp_synch_Tab_Domaine_Competences @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Domaine_Competences] AS Target
USING ['+@db_source+'].[dbo].[Tab_Domaine_Competences] AS Source
ON (1=1 and ( Target.[Code_Domaine_Competence] = ('''+@code+'''+Source.[Code_Domaine_Competence] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Domaine] = Source.[Code_Domaine],
Target.[Libelle_Domaine_Competence] = Source.[Libelle_Domaine_Competence],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Domaine_Competence],
[Code_Domaine],
[Libelle_Domaine_Competence],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Domaine_Competence]),
Source.[Code_Domaine],
Source.[Libelle_Domaine_Competence],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

