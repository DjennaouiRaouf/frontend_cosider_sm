CREATE TRIGGER TR_Update_Date_Modification_Tab_Objectifs_Formation ON Tab_Objectifs_Formation
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Objectifs_Formation AS A
														INNER JOIN INSERTED AS B ON A.ID_Objectifs_Formation = B.ID_Objectifs_Formation
														INNER JOIN DELETED AS C ON A.ID_Objectifs_Formation = C.ID_Objectifs_Formation
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

