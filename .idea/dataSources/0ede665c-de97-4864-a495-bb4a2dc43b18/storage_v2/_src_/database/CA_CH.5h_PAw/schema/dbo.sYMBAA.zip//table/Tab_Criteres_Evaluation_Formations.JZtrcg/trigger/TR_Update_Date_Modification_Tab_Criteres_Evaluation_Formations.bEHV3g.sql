CREATE TRIGGER TR_Update_Date_Modification_Tab_Criteres_Evaluation_Formations ON Tab_Criteres_Evaluation_Formations
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Criteres_Evaluation_Formations AS A
														INNER JOIN INSERTED AS B ON A.Code_Criteres_Evaluation_Formation = B.Code_Criteres_Evaluation_Formation
														INNER JOIN DELETED AS C ON A.Code_Criteres_Evaluation_Formation = C.Code_Criteres_Evaluation_Formation
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

