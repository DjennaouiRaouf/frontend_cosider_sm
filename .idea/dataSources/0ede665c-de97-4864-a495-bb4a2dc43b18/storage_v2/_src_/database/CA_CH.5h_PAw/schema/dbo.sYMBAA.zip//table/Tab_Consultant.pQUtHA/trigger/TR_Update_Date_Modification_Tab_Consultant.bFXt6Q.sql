CREATE TRIGGER TR_Update_Date_Modification_Tab_Consultant ON Tab_Consultant
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Consultant AS A
														INNER JOIN INSERTED AS B ON A.ID_Consultant = B.ID_Consultant
														INNER JOIN DELETED AS C ON A.ID_Consultant = C.ID_Consultant
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

