-- FONCTION Fct_Cnas_Annuel

CREATE FUNCTION [dbo].[Fct_Cans_Annuel] (@cna varchar(5) ,@dure varchar(5),@dt_debut date,@dt_Fin date,@cd_casse varchar(15)) 
returns table as return
(
select a.matricule,a.nom,a.prenom,a.Num_SS,a.Genre,a.Date_Naissance,b.mmaa,COALESCE(b.Taux,0,2) as Dure_Travail,
sum(b.Base) over (partition by a.Matricule ) as total_annuel,
b.Base,c.Situation_Famille,c.Libelle_poste_travail,d.Libelle_Caisse,ISNULL(EV.Date_Evenement,f.Date_Debut_Contrat) as Date_Recrutement,IIF(g.Avec_Depart = 1 AND g.Avec_Retour = 0,g.Date_Sortie,NULL) as Date_Sortie from Tab_Agent as a

    cross apply
    (select f.Matricule,f.Mmaa,f.Base,g.Taux from
    (select matricule,Code_Rubrique,mmaa,Base from Tab_Archive_Paie 
    where  code_rubrique = @cna) as f
    
    left join (select matricule,Code_Rubrique,mmaa,Base,Taux from Tab_Archive_Paie
    where code_rubrique = @dure  
    ) as g on f.matricule=g.matricule and f.mmaa=g.Mmaa) as b

    cross apply (select top 1 pt.Libelle_poste_travail,ib.Code_Information_Bulletin_Agent,ib.Situation_Famille,ib.Code_Poste_Travail
     from Tab_Information_Bulletin_Agent as ib,Tab_Poste_Travail as pt
    where a.Matricule=ib.Matricule and ib.Code_Poste_Travail=pt.Code_Poste_Travail and ib.Est_Bloquer = 0
    order by Code_Information_Bulletin_Agent desc) as c
    
    outer apply(select Libelle_Caisse from Tab_Caisse_Cotisation where a.Code_Caisse=Code_Caisse) as d

    outer apply
    (select top 1 Date_Debut_Contrat from Tab_Agent_Contrat
    where a.Matricule = Matricule and Est_Bloquer = 0
    order by Nbr_Contrat asc) as f

    OUTER APPLY (SELECT TOP 1 EV.Date_Evenement FROM Tab_Evenement_Agent AS EV 
        OUTER APPLY (SELECT B.* FROM Tab_Evenement_RH AS B WHERE B.Code_Evenement = EV.Code_Evenement ) AS B
    WHERE EV.Matricule = A.Matricule AND EV.Est_Bloquer = 0  AND B.Avec_Reintegration = 1 ORDER BY EV.Code_Evenement_Agent DESC ) AS EV

    outer apply
     (select top 1 Code_Evenement_Agent,er.Code_Evenement,Date_Evenement as Date_Sortie,er.Avec_Depart,er.Avec_Retour 
 from Tab_Evenement_Agent as eg 
 inner join Tab_Evenement_RH  as er on eg.Code_Evenement = er.Code_Evenement
 where a.Matricule = Matricule and /*(er.Avec_Depart = 1 and er.Avec_Retour = 0) and*/ eg.Est_Bloquer = 0 order by eg.Date_Evenement desc) as g

        
    where a.Matricule=b.Matricule  and b.Mmaa between @dt_debut and @dt_Fin and a.Code_Caisse=@cd_casse
     
)
go

