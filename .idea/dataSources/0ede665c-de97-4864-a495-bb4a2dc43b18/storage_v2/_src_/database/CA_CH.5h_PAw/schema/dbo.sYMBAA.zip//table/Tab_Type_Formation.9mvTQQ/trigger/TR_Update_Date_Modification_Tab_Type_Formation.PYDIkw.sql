CREATE TRIGGER TR_Update_Date_Modification_Tab_Type_Formation ON Tab_Type_Formation
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Type_Formation AS A
														INNER JOIN INSERTED AS B ON A.Code_Type_Formation = B.Code_Type_Formation
														INNER JOIN DELETED AS C ON A.Code_Type_Formation = C.Code_Type_Formation
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

