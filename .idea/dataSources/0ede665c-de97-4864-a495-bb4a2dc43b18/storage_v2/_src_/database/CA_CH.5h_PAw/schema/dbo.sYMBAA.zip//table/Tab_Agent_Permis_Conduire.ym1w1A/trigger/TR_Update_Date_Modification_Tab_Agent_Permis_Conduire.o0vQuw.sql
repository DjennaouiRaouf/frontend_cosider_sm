CREATE TRIGGER TR_Update_Date_Modification_Tab_Agent_Permis_Conduire ON Tab_Agent_Permis_Conduire
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Agent_Permis_Conduire AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Matricule, A.Categorie) = CONCAT (B.Matricule, B.Categorie)
														INNER JOIN DELETED AS C ON CONCAT (A.Matricule, A.Categorie) = CONCAT (C.Matricule, C.Categorie)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

