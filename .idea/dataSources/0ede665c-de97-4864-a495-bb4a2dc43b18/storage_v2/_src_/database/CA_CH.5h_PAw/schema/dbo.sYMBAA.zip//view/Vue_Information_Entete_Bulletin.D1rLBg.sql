---------------------Fin-------------------------------------

----------------Alter View Vue_Information_Entete_Bulletin------------
CREATE view [dbo].[Vue_Information_Entete_Bulletin] (Matricule,Nom,Prenom,Num_SS,Nbr_Enfant,[Classification],Num_Compte,Situation_Famille,Code_Structure,Libelle_Agence,
Libelle_Structure,Libelle_poste_travail,Taux_Statut_Horaire,Date_Debut_Contrat,Num_SS_Employeur)
as SELECT a.Matricule,a.Nom,a.Prenom,a.Num_SS,a.Nbr_Enfant,
b.[Classification],b.Num_Compte,b.Situation_Famille,b.Code_Structure,c.Libelle_Agence,
iif(dbo.[Fct_Recuperer_Structure_Afficher_Dans_Bulletin](b.Code_Structure) is null,d.Libelle_Structure,dbo.[Fct_Recuperer_Structure_Afficher_Dans_Bulletin](b.Code_Structure)) as Libelle_Structure,

e.Libelle_poste_travail,f.Taux_Statut_Horaire,g.Date_Debut_Contrat,h.Num_SS_Employeur FROM Tab_Agent as a

    CROSS APPLY ( select top 1 Matricule,[Classification],Num_Compte,Code_Agence,Code_Structure,Situation_Famille,
            Code_Poste_Travail,Code_Statut_Horaire FROM Tab_Information_Bulletin_Agent WHERE a.Matricule = Matricule AND Est_Bloquer = 0
    ORDER BY Code_Information_Bulletin_Agent DESC )as b

	left join Tab_Caisse_Cotisation as h on a.Code_Caisse=h.Code_Caisse

    left join Tab_Agence as c on c.Code_Agence=b.Code_Agence
	inner join Tab_Structures as d on b.Code_Structure=d.Code_Structure
	inner join Tab_Poste_Travail as e on b.Code_Poste_Travail=e.Code_Poste_Travail
	inner join Tab_Statut_Horaire as f on b.Code_Statut_Horaire=f.Code_Statut_Horaire
    CROSS APPLY (SELECT Top 1 Date_Debut_Contrat from Tab_Agent_Contrat where b.Matricule = Matricule AND Est_Bloquer = 0 ORDER BY Date_Debut_Contrat asc ) as g 
go

