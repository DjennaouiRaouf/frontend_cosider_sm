CREATE TRIGGER TR_Update_Date_Modification_Tab_Domaine_Competences ON Tab_Domaine_Competences
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Domaine_Competences AS A
														INNER JOIN INSERTED AS B ON A.Code_Domaine_Competence = B.Code_Domaine_Competence
														INNER JOIN DELETED AS C ON A.Code_Domaine_Competence = C.Code_Domaine_Competence
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

