CREATE TRIGGER TR_Update_Date_Modification_Tab_Famille_Structures ON Tab_Famille_Structures
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Famille_Structures AS A
														INNER JOIN INSERTED AS B ON A.Code_Famille_Structure = B.Code_Famille_Structure
														INNER JOIN DELETED AS C ON A.Code_Famille_Structure = C.Code_Famille_Structure
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

