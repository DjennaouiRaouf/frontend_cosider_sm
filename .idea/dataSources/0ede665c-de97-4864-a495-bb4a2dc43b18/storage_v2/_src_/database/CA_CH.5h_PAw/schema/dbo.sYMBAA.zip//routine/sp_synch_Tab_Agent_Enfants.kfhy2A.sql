
CREATE   procedure sp_synch_Tab_Agent_Enfants @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Enfants] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Enfants] AS Source
ON (1=1 and ( Target.[Code_Agent_Enfant] = ('''+@code+'''+Source.[Code_Agent_Enfant] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Genre] = Source.[Genre],
Target.[Nom_Enfant] = Source.[Nom_Enfant],
Target.[Prenom_Enfant] = Source.[Prenom_Enfant],
Target.[Date_Naissance_Enfant] = Source.[Date_Naissance_Enfant],
Target.[Code_Commune_Naissance] = Source.[Code_Commune_Naissance],
Target.[Date_Deces_Enfant] = Source.[Date_Deces_Enfant],
Target.[Scolarise] = Source.[Scolarise],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Agent_Enfant],
[Matricule],
[Genre],
[Nom_Enfant],
[Prenom_Enfant],
[Date_Naissance_Enfant],
[Code_Commune_Naissance],
[Date_Deces_Enfant],
[Scolarise],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Agent_Enfant]),
('''+@code+'''+Source.[Matricule]),
Source.[Genre],
Source.[Nom_Enfant],
Source.[Prenom_Enfant],
Source.[Date_Naissance_Enfant],
Source.[Code_Commune_Naissance],
Source.[Date_Deces_Enfant],
Source.[Scolarise],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

