CREATE TRIGGER TR_Update_Date_Modification_Tab_Agent_Conjoint ON Tab_Agent_Conjoint
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Agent_Conjoint AS A
														INNER JOIN INSERTED AS B ON A.Code_Agent_Conjoint = B.Code_Agent_Conjoint
														INNER JOIN DELETED AS C ON A.Code_Agent_Conjoint = C.Code_Agent_Conjoint
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

