CREATE TRIGGER TR_Update_Date_Modification_Tab_Niveau_Etudes ON Tab_Niveau_Etudes
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Niveau_Etudes AS A
														INNER JOIN INSERTED AS B ON A.Code_Niveau_Etudes = B.Code_Niveau_Etudes
														INNER JOIN DELETED AS C ON A.Code_Niveau_Etudes = C.Code_Niveau_Etudes
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

