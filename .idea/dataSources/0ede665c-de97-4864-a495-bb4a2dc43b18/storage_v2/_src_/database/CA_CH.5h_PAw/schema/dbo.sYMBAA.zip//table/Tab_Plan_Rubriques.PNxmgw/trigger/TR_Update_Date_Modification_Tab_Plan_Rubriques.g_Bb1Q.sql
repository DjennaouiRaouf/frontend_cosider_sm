CREATE TRIGGER TR_Update_Date_Modification_Tab_Plan_Rubriques ON Tab_Plan_Rubriques
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Plan_Rubriques AS A
														INNER JOIN INSERTED AS B ON A.Code_Rubrique = B.Code_Rubrique
														INNER JOIN DELETED AS C ON A.Code_Rubrique = C.Code_Rubrique
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

