

-----Fonction Charges_Previsionnelle

CREATE function [dbo].[Fct_charges_Previsionnelle] (@Date_Debut date,@Date_Fin date) 
returns table as return
(
select a.*,
isnull(g.Prevision_Mens_MO,0) as Prevision_Mens_MO,isnull(h.Prevision_Mens_MX,0) as Prevision_Mens_MX,
isnull(i.Prevision_Mens_ML,0) as Prevision_Mens_ML,isnull(j.Prevision_Mens_FG,0) as Prevision_Mens_FG,
isnull(k.Prevision_Mens_ST,0) as Prevision_Mens_ST,
isnull(b.Prevision_Ann_MO,0) as Prevision_Ann_MO,isnull(c.Prevision_Ann_MX,0) as Prevision_Ann_MX,
isnull(d.Prevision_Ann_ML,0) as Prevision_Ann_ML,isnull(e.Prevision_Ann_FG,0) as Prevision_Ann_FG,
isnull(f.Prevision_Ann_ST,0) as Prevision_Ann_ST

FROM [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a
left join
(select Code_site,sum(Valeur) as Prevision_Ann_MO from Tab_Detaille_Charge 
where Code_Type_Charge='01' and  Prevu_Realiser='P' and   (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as b on a.Code_site=b.Code_site 

left join

(select a.Code_site,sum(Valeur) as Prevision_Ann_MX from Tab_Detaille_Charge as a
where Code_Type_Charge='02' and  Prevu_Realiser='P' and   (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as c on a.Code_site=c.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Ann_ML from Tab_Detaille_Charge as a
where Code_Type_Charge='03' and  Prevu_Realiser='P' and   (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as d on a.Code_site=d.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Ann_FG from Tab_Detaille_Charge as a
where Code_Type_Charge='04' and  Prevu_Realiser='P' and   (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as e on a.Code_site=e.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Ann_ST from Tab_Detaille_Charge as a
where Code_Type_Charge='05' and  Prevu_Realiser='P' and   (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as f on a.Code_site=f.Code_site

left join
(select Code_site,sum(Valeur) as Prevision_Mens_MO from Tab_Detaille_Charge 
where Code_Type_Charge='01' and  Prevu_Realiser='P' and mmaa=@Date_Fin
group by Code_site) as g on a.Code_site=g.Code_site 

left join

(select a.Code_site,sum(Valeur) as Prevision_Mens_MX from Tab_Detaille_Charge as a
where Code_Type_Charge='02' and  Prevu_Realiser='P'  and mmaa=@Date_Fin
group by a.Code_site) as h on a.Code_site=h.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Mens_ML from Tab_Detaille_Charge as a
where Code_Type_Charge='03' and  Prevu_Realiser='P' and  mmaa=@Date_Fin
group by a.Code_site) as i on a.Code_site=i.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Mens_FG from Tab_Detaille_Charge as a
where Code_Type_Charge='04' and  Prevu_Realiser='P' and mmaa=@Date_Fin
group by a.Code_site) as j on a.Code_site=j.Code_site

left join

(select a.Code_site,sum(Valeur) as Prevision_Mens_ST from Tab_Detaille_Charge as a
where Code_Type_Charge='05' and  Prevu_Realiser='P' and mmaa=@Date_Fin
group by a.Code_site) as k on a.Code_site=k.Code_site
)
go

