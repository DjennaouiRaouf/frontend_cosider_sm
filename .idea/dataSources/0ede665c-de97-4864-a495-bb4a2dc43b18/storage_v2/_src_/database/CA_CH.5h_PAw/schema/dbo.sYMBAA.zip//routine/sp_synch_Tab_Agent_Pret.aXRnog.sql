
CREATE   procedure sp_synch_Tab_Agent_Pret @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent_Pret] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent_Pret] AS Source
ON (1=1 and ( Target.[Code_Pret] = ('''+@code+'''+Source.[Code_Pret] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Date_Effectif_Pret] = Source.[Date_Effectif_Pret],
Target.[Date_Debut] = Source.[Date_Debut],
Target.[Date_Fin_Pret] = Source.[Date_Fin_Pret],
Target.[Montant_Pret] = Source.[Montant_Pret],
Target.[Montant_Mensuel] = Source.[Montant_Mensuel],
Target.[Cumule_Rembourse] = Source.[Cumule_Rembourse],
Target.[Etat_Pret] = Source.[Etat_Pret],
Target.[Matricule] = ('''+@code+'''+Source.[Matricule]),
Target.[Code_Decision] = ('''+@code+'''+Source.[Code_Decision]),
Target.[Code_Rubrique] = Source.[Code_Rubrique],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Pret],
[Date_Effectif_Pret],
[Date_Debut],
[Date_Fin_Pret],
[Montant_Pret],
[Montant_Mensuel],
[Cumule_Rembourse],
[Etat_Pret],
[Matricule],
[Code_Decision],
[Code_Rubrique],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Pret]),
Source.[Date_Effectif_Pret],
Source.[Date_Debut],
Source.[Date_Fin_Pret],
Source.[Montant_Pret],
Source.[Montant_Mensuel],
Source.[Cumule_Rembourse],
Source.[Etat_Pret],
('''+@code+'''+Source.[Matricule]),
('''+@code+'''+Source.[Code_Decision]),
Source.[Code_Rubrique],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

