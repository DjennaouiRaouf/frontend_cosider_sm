
-- Vue_Information_Pour_Archiver_Paie_Courante

CREATE VIEW [dbo].[Vue_Information_Pour_Archiver_Paie_Courante](Code_Information_Bulletin_Agent,Matricule,Code_Rubrique,Mmaa,Base,Taux,Mmaadb,Mmaadf,Mode_Saisie,Montant,Observation,User_ID,Date_Modification)
as SELECT b.Code_Information_Bulletin_Agent,a.Matricule, a.Code_Rubrique,replace (c.Contenue_Parametre,';','') as Mmaa, a.Base, a.Taux,  a.Mmaadb, a.Mmaadf, a.Mode_Saisie,a.Montant, a.Observation,a.User_ID,CURRENT_TIMESTAMP as Date_Modification 
FROM Tab_Calcul_Paie as a,Tab_Constantes_Parametrables as c
CROSS APPLY
( SELECT * FROM
(
SELECT *,ROW_NUMBER() OVER (PARTITION BY MATRICULE ORDER BY Code_Information_Bulletin_Agent DESC) as RN
FROM Tab_Information_Bulletin_Agent
) as t
where t.RN=1) as b
where a.Matricule = b.Matricule and c.Code_Parametre = 'Mois' 

go

