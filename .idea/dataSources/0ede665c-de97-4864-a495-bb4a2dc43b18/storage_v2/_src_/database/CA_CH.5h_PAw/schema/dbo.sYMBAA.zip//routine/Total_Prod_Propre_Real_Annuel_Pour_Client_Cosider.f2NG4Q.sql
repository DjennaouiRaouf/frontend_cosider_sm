
-----Creation FUNCTION [dbo].[Total_Prod_Propre_Real_Annuel_Client_Cosider] 
CREATE FUNCTION [dbo].[Total_Prod_Propre_Real_Annuel_Pour_Client_Cosider] (
@Code_Site varchar(10),
@Date_Debut date,
@Date_Fin date
) returns money

as 
begin
declare @Total_Production money
set @Total_Production=(select sum(a.Valeur_1+a.Valeur_2+a.Valeur_3)  Total_Annuel_Realise_prod_propre from Tab_Production as a
inner join Tab_NT as b on a.Code_site=b.Code_site and a.NT=b.NT
inner join Tab_Client as c on b.Code_Client=c.Code_Client
where a.Code_site=@Code_Site and Code_Type_Production='01' and Prevu_Realiser='R' and (mmaa between @Date_Debut and @Date_Fin)  and c.Est_Client_Cosider=1
group by a.Code_site)
RETURN isnull(@Total_Production,0)
end;
go

