
CREATE   procedure sp_synch_Tab_Historique_Information_Caisse_Cotisation @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Historique_Information_Caisse_Cotisation] AS Target
USING ['+@db_source+'].[dbo].[Tab_Historique_Information_Caisse_Cotisation] AS Source
ON (1=1 and ( Target.[Matricule_Apprenti] = ('''+@code+'''+Source.[Matricule_Apprenti] )) and ( Target.[Matricule_Maitre_Apprenti] = ('''+@code+'''+Source.[Matricule_Maitre_Apprenti] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Caisse],
[Libelle_Caisse],
[Mmaa],
[Num_SS_Employeur],
[Date_Interval],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Caisse]),
Source.[Libelle_Caisse],
Source.[Mmaa],
Source.[Est_Bloquer],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

