CREATE TRIGGER TR_Update_Date_Modification_Tab_Reliquat_Conge_Annuel ON Tab_Reliquat_Conge_Annuel
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Reliquat_Conge_Annuel AS A
														INNER JOIN INSERTED AS B ON A.ID_Tab_Reliquat_Conge_Annuel = B.ID_Tab_Reliquat_Conge_Annuel
														INNER JOIN DELETED AS C ON A.ID_Tab_Reliquat_Conge_Annuel = C.ID_Tab_Reliquat_Conge_Annuel
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

