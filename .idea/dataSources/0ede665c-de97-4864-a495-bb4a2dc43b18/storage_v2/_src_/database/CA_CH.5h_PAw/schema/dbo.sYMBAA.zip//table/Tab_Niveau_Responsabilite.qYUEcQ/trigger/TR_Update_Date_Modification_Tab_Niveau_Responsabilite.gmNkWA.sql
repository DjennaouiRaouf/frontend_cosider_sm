CREATE TRIGGER TR_Update_Date_Modification_Tab_Niveau_Responsabilite ON Tab_Niveau_Responsabilite
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Niveau_Responsabilite AS A
														INNER JOIN INSERTED AS B ON A.Code_Niveau_Resp = B.Code_Niveau_Resp
														INNER JOIN DELETED AS C ON A.Code_Niveau_Resp = C.Code_Niveau_Resp
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

