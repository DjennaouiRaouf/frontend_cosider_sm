
-- Creation Trigger pour la table Agent_Qualification

CREATE trigger [dbo].[atr_i_Agent_Quailfication_check_Est_Principal] ON [dbo].[Tab_Agent_Qualification] AFTER INSERT,UPDATE as

BEGIN
if EXISTS
(
SELECT c.Matricule,COUNT(c.matricule) as Nombre_est_paricipal FROM Tab_Agent_Qualification as c
inner join inserted  as d on c.Matricule=d.Matricule
WHERE c.Est_Principal=1
group by c.Matricule
having COUNT(c.matricule)>1
)
begin

update A
set A.Est_Principal=0
from
Tab_Agent_Qualification as A
inner join inserted as B on A.Matricule=B.Matricule
and A.Code_Qualification<>B.Code_Qualification 

END

END

go

