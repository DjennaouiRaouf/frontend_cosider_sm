
CREATE   procedure sp_synch_Tab_Agent @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Agent] AS Target
USING ['+@db_source+'].[dbo].[Tab_Agent] AS Source
ON (1=1 and ( Target.[Matricule] = ('''+@code+'''+Source.[Matricule] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Prenom] = Source.[Prenom],
Target.[Nom] = Source.[Nom],
Target.[Code_Commune_Residence] = Source.[Code_Commune_Residence],
Target.[Code_Commune_Naissance] = Source.[Code_Commune_Naissance],
Target.[Date_Naissance] = Source.[Date_Naissance],
Target.[Num_SS] = Source.[Num_SS],
Target.[Nationalite] = Source.[Nationalite],
Target.[Nbr_Enfant] = Source.[Nbr_Enfant],
Target.[Observation] = Source.[Observation],
Target.[Photo] = Source.[Photo],
Target.[Nbr_Annee_Exp_Hors_Entreprise] = Source.[Nbr_Annee_Exp_Hors_Entreprise],
Target.[Distance_KM] = Source.[Distance_KM],
Target.[Code_Dossier] = Source.[Code_Dossier],
Target.[Type_Charge_Agent] = Source.[Type_Charge_Agent],
Target.[Nbr_Annee_Exp_Entreprise] = Source.[Nbr_Annee_Exp_Entreprise],
Target.[Civilite] = Source.[Civilite],
Target.[Genre] = Source.[Genre],
Target.[Code_Caisse] = ('''+@code+'''+Source.[Code_Caisse]),
Target.[Annee_Presumee] = Source.[Annee_Presumee],
Target.[Ancien_Matricule] = ('''+@code+'''+Source.[Ancien_Matricule]),
Target.[Avec_Mutuel] = Source.[Avec_Mutuel],
Target.[Montant_Assurance_Groupe] = Source.[Montant_Assurance_Groupe],
Target.[Avec_Cacobath] = Source.[Avec_Cacobath],
Target.[Avec_Chomage_Intemperie] = Source.[Avec_Chomage_Intemperie],
Target.[Avec_Oprebat] = Source.[Avec_Oprebat],
Target.[Groupe_Sanguine] = Source.[Groupe_Sanguine],
Target.[Est_Apprenti] = Source.[Est_Apprenti],
Target.[Est_Maitre_Apprentissage] = Source.[Est_Maitre_Apprentissage],
Target.[Est_Formateur] = Source.[Est_Formateur],
Target.[Handicap] = Source.[Handicap],
Target.[Abattement_IRG] = Source.[Abattement_IRG],
Target.[TAUX_CNAS] = Source.[TAUX_CNAS],
Target.[Avec_Abattement_CNAS] = Source.[Avec_Abattement_CNAS],
Target.[NIN] = Source.[NIN],
Target.[IdNat] = Source.[IdNat],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Matricule],[Prenom],[Nom],
[Code_Commune_Residence],[Code_Commune_Naissance],
[Date_Naissance],[Num_SS],[Nationalite],
[Nbr_Enfant],[Observation],[Photo],
[Nbr_Annee_Exp_Hors_Entreprise],[Distance_KM],
[Code_Dossier],[Type_Charge_Agent],[Nbr_Annee_Exp_Entreprise],
[Civilite],[Genre],[Code_Caisse],[Annee_Presumee],
[Ancien_Matricule],[Avec_Mutuel],[Montant_Assurance_Groupe],
[Avec_Cacobath],[Avec_Chomage_Intemperie],[Avec_Oprebat],
[Groupe_Sanguine],[Est_Apprenti],[Est_Maitre_Apprentissage],
[Est_Formateur],[Handicap],[Abattement_IRG],[TAUX_CNAS],
[Avec_Abattement_CNAS],[NIN],[IdNat],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Matricule]),Source.[Prenom],Source.[Nom],
Source.[Code_Commune_Residence],Source.[Code_Commune_Naissance],Source.[Date_Naissance],
Source.[Num_SS],Source.[Nationalite],Source.[Nbr_Enfant],
Source.[Observation],Source.[Photo],Source.[Nbr_Annee_Exp_Hors_Entreprise],
Source.[Distance_KM],Source.[Code_Dossier],Source.[Type_Charge_Agent],
Source.[Nbr_Annee_Exp_Entreprise],Source.[Civilite],Source.[Genre],
('''+@code+'''+Source.[Code_Caisse]),Source.[Annee_Presumee],('''+@code+'''+Source.[Ancien_Matricule]),
Source.[Avec_Mutuel],Source.[Montant_Assurance_Groupe],Source.[Avec_Cacobath],
Source.[Avec_Chomage_Intemperie],Source.[Avec_Oprebat],Source.[Groupe_Sanguine],Source.[Est_Apprenti],Source.[Est_Maitre_Apprentissage],
Source.[Est_Formateur],Source.[Handicap],Source.[Abattement_IRG],Source.[TAUX_CNAS],Source.[Avec_Abattement_CNAS],Source.[NIN],
Source.[IdNat],case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]);'
exec (@sql_interne)
end
go

