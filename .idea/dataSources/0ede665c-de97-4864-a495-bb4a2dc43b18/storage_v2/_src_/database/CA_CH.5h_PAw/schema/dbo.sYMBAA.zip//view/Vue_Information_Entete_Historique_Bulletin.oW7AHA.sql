---------------Fin---------------------------------------------------

------Alter Vue_Information_Entete_Historique_Bulletin--------------------

CREATE view [dbo].[Vue_Information_Entete_Historique_Bulletin] (Matricule,Num_SS,Nom,Prenom,Nbr_Enfant,[Classification],Num_Compte,Situation_Famille,Libelle_Agence,
Libelle_Structure,Libelle_poste_travail,Taux_Statut_Horaire,Date_Debut_Contrat,mmaa,Code_Information_Bulletin_Agent,Code_Structure,Num_SS_Employeur)
as SELECT a.Matricule,a.Num_SS,b.Nom,b.Prenom,b.Nbr_Enfant,
b.[Classification],b.Num_Compte,b.Situation_Famille,c.Libelle_Agence,
iif(dbo.[Fct_Recuperer_Structure_Afficher_Dans_Bulletin](b.Code_Structure) is null,d.Libelle_Structure,dbo.[Fct_Recuperer_Structure_Afficher_Dans_Bulletin](b.Code_Structure)) as Libelle_Structure,
e.Libelle_poste_travail,f.Taux_Statut_Horaire,g.Date_Debut_Contrat,
h.mmaa,h.Code_Information_Bulletin_Agent,b.Code_Structure,[dbo].[Fct_Recuperer_Num_Adherent](b.Code_Caisse,h.Mmaa) as Num_SS_Employeur FROM Tab_Agent as a

inner join (SELECT DISTINCT matricule,mmaa,Code_Information_Bulletin_Agent FROM Tab_Archive_Paie) as h on a.Matricule=h.Matricule

inner join (SELECT Matricule,Code_Information_Bulletin_Agent,Nom,Prenom,Nbr_Enfant,[Classification],Num_Compte,Code_Agence,Code_Structure,Situation_Famille,
           Code_Poste_Travail,Code_Statut_Horaire,Code_Caisse from Tab_Information_Bulletin_Agent where Est_Bloquer = 0 ) as b on b.Code_Information_Bulletin_Agent=h.Code_Information_Bulletin_Agent

left join Tab_Agence as c on  b.Code_Agence = c.Code_Agence
inner join Tab_Structures as d on b.Code_Structure=d.Code_Structure
inner join Tab_Poste_Travail as e on b.Code_Poste_Travail=e.Code_Poste_Travail
inner join Tab_Statut_Horaire as f on b.Code_Statut_Horaire=f.Code_Statut_Horaire
CROSS APPLY (SELECT Top 1 Date_Debut_Contrat from Tab_Agent_Contrat where b.Matricule = Matricule AND Est_Bloquer = 0 ORDER BY Date_Debut_Contrat asc ) as g 
    
go

