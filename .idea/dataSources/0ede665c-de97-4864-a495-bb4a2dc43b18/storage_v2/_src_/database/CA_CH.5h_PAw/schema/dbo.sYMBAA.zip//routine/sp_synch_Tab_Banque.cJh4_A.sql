CREATE   procedure sp_synch_Tab_Banque @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Banque] AS Target
USING ['+@db_source+'].[dbo].[Tab_Banque] AS Source
ON (1=1 and ( Target.[Code_Banque] = ('''+@code+'''+Source.[Code_Banque] )))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Libelle_Banque] = Source.[Libelle_Banque],
Target.[Acronyme] = Source.[Acronyme],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_Banque],
[Libelle_Banque],
[Acronyme],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
('''+@code+'''+Source.[Code_Banque]),
Source.[Libelle_Banque],
Source.[Acronyme],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

