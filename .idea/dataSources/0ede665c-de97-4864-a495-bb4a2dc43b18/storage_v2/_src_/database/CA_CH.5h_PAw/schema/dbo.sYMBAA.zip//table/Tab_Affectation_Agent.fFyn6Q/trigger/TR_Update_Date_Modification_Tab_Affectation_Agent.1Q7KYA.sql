CREATE TRIGGER TR_Update_Date_Modification_Tab_Affectation_Agent ON Tab_Affectation_Agent
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Affectation_Agent AS A
														INNER JOIN INSERTED AS B ON A.ID_Affectation_Agent = B.ID_Affectation_Agent
														INNER JOIN DELETED AS C ON A.ID_Affectation_Agent = C.ID_Affectation_Agent
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

