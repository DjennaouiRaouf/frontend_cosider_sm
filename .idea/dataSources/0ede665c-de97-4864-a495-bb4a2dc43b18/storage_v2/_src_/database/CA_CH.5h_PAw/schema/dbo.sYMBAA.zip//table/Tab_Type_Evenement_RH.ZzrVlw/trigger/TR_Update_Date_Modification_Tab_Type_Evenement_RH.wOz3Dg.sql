CREATE TRIGGER TR_Update_Date_Modification_Tab_Type_Evenement_RH ON Tab_Type_Evenement_RH
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Type_Evenement_RH AS A
														INNER JOIN INSERTED AS B ON A.Code_Type_Evenement = B.Code_Type_Evenement
														INNER JOIN DELETED AS C ON A.Code_Type_Evenement = C.Code_Type_Evenement
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

