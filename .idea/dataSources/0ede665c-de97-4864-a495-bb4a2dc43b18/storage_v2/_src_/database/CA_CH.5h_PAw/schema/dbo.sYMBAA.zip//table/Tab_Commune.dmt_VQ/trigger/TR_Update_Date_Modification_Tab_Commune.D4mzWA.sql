CREATE TRIGGER TR_Update_Date_Modification_Tab_Commune ON Tab_Commune
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Commune AS A
														INNER JOIN INSERTED AS B ON A.Code_Commune_Ons = B.Code_Commune_Ons
														INNER JOIN DELETED AS C ON A.Code_Commune_Ons = C.Code_Commune_Ons
												WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

