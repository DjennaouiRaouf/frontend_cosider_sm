CREATE TRIGGER TR_Update_Date_Modification_Tab_Taches_Poste_Travail ON Tab_Taches_Poste_Travail
											AFTER UPDATE
											AS 
											BEGIN
												update A
													SET A.Date_Modification = CURRENT_TIMESTAMP
													FROM
														Tab_Taches_Poste_Travail AS A
														INNER JOIN INSERTED AS B on CONCAT (A.Code_Taches_Generique, A.Code_Poste_Travail) = CONCAT (B.Code_Taches_Generique, B.Code_Poste_Travail)
														INNER JOIN DELETED AS C ON CONCAT (A.Code_Taches_Generique, A.Code_Poste_Travail) = CONCAT (C.Code_Taches_Generique, C.Code_Poste_Travail)
													WHERE B.Date_Modification IS NULL OR C.Date_Modification = A.Date_Modification
											END;
go

