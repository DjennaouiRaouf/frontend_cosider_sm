CREATE   procedure sp_synch_Tab_Entreprise (@db_source varchar(max), @codel varchar(max) )
as
begin

    DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Entreprise] AS Target
    USING ['+@db_source+'].[dbo].[Tab_Entreprise] AS Source
    ON (1=1 and ( Target.[Code_Entreprise] = ''X'' ))
    WHEN MATCHED
    THEN
        UPDATE SET Target.[Code_Entreprise] = ''X''
    WHEN NOT MATCHED
    THEN
        INSERT (
        [Code_Entreprise],
        [Raison_Social],
        [Num_Fiscal],
        [Num_Article],
        [Num_Registre_Commerce],
        [Num_Compte],
        [Capital],
        [Entete],
        [Date_Registre_Commerce],
        [Logo],
        [Type_Dossier],
        [User_ID],
        [Date_Modification]
        )
        VALUES (
        Source.[Code_Entreprise],
        Source.[Raison_Social],
        Source.[Num_Fiscal],
        Source.[Num_Article],
        Source.[Num_Registre_Commerce],
        Source.[Num_Compte],
        Source.[Capital],
        Source.[Entete],
        Source.[Date_Registre_Commerce],
        Source.[Logo],
        Source.[Type_Dossier],
        case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@codel+'''+Source.[User_ID]) else Null end ,
        Source.[Date_Modification]
    );'
    exec (@sql_interne)
end
go

