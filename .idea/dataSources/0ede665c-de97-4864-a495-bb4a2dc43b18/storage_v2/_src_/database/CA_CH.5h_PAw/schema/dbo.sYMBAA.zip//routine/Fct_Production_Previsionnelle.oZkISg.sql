-- FONCTION Production_Previsionnelle

CREATE function [dbo].[Fct_Production_Previsionnelle] (@Date_Debut date,@Date_Fin date) 
returns table as return
(
SELECT 

 a.*,
 (isnull(f.Total_Mensuel_Prevu_prod_propre,0)-isnull(i.Total_Mensuel_Prevu_prod_ST,0)) as Total_Mensuel_Prevu_prod_propre,
 (isnull(g.Total_Mensuel_Prevu_prod_preste1,0)+isnull(h.Total_Mensuel_Prevu_prod_preste2,0)) as Total_Mensuel_Prevu_prod_preste,
 isnull(i.Total_Mensuel_Prevu_prod_ST,0) as Total_Mensuel_Prevu_prod_ST,
 (isnull(b.Total_Annuel_Prevu_prod_propre,0)-isnull(e.Total_Annuel_Prevu_prod_ST,0)) as Total_Annuel_Prevu_prod_propre,
 (isnull(c.Total_Annuel_Prevu_prod_preste1,0)+isnull(d.Total_Annuel_Prevu_prod_preste2,0)) as Total_Annuel_Prevu_prod_preste,
 isnull(e.Total_Annuel_Prevu_prod_ST,0) as Total_Annuel_Prevu_prod_ST
 FROM [Fct_Liste_Site_de_L_Anne] (@Date_Debut,@Date_Fin) as a
left join
(select Code_site,sum(Valeur_1)  Total_Annuel_Prevu_prod_propre from Tab_Production 
where Code_Type_Production='01' and Prevu_Realiser='P' and  (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as b on a.Code_site=b.Code_site

left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Annuel_Prevu_prod_preste1 from Tab_Production 
where  Code_Type_Production='02' and Prevu_Realiser='P'  and  (mmaa between @Date_Debut and @Date_Fin)
group by Code_site) as c on a.Code_site=c.Code_site

left join

(select Recepteur,isnull(sum(Valeur_1)*-1,0) as Total_Annuel_Prevu_prod_preste2 from Tab_Production 
where Code_Type_Production='02'  and Prevu_Realiser='P' and (mmaa between @Date_Debut and @Date_Fin)
group by Recepteur) as d on a.Code_site=d.Recepteur

left join

(select a.Code_site,sum(Valeur_1) as Total_Annuel_Prevu_prod_ST from Tab_Production as a
where Code_Type_Production='03' and Prevu_Realiser='P' and (mmaa between @Date_Debut and @Date_Fin)
group by a.Code_site) as e on a.Code_site=e.Code_site

left join
(select Code_site,sum(Valeur_1)  Total_Mensuel_Prevu_prod_propre from Tab_Production 
where Code_Type_Production='01' and Prevu_Realiser='P' and  mmaa=@Date_Fin
group by Code_site) as f on a.Code_site=f.Code_site

left join
(select Code_site,isnull(sum(Valeur_1),0) as Total_Mensuel_Prevu_prod_preste1 from Tab_Production 
where  Code_Type_Production='02' and Prevu_Realiser='P'  and  mmaa=@Date_Fin
group by Code_site) as g on a.Code_site=g.Code_site

left join

(select Recepteur,isnull(sum(Valeur_1)*-1,0) as Total_Mensuel_Prevu_prod_preste2 from Tab_Production 
where Code_Type_Production='02'  and Prevu_Realiser='P' and mmaa=@Date_Fin
group by Recepteur) as h on a.Code_site=h.Recepteur

left join

(select a.Code_site,sum(Valeur_1) as Total_Mensuel_Prevu_prod_ST from Tab_Production as a
where Code_Type_Production='03' and Prevu_Realiser='P' and mmaa=@Date_Fin
group by a.Code_site) as i on a.Code_site=i.Code_site
)
go

