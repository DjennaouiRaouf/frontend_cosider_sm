create   proc sp_synch_Global @db_source varchar(max), @code varchar(max)
as
BEGIN

	print 'Consolidation de la table Tab_Entreprise'
	exec ('sp_synch_Tab_Entreprise '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Banque'
	exec ('sp_synch_Tab_Banque '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agence'
	exec ('sp_synch_Tab_Agence '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Filiale'
	exec ('sp_synch_Tab_Filiale '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Site'
	exec ('sp_synch_Tab_Site '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Structures'
	exec ('sp_synch_Tab_Structures '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Caisse_Cotisation'
	exec ('sp_synch_Tab_Caisse_Cotisation '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent'
	exec ('sp_synch_Tab_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Contrat'
	exec ('sp_synch_Tab_Agent_Contrat '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Permis_Conduire'
	exec ('sp_synch_Tab_Agent_Permis_Conduire '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Affectation_Agent'
	exec ('sp_synch_Tab_Affectation_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Domaine_Competences'
	exec ('sp_synch_Tab_Domaine_Competences '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Competences'
	exec ('sp_synch_Tab_Competences '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Competences'
	exec ('sp_synch_Tab_Agent_Competences '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Conge_Annuel'
	exec ('sp_synch_Tab_Agent_Conge_Annuel '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Conjoint'
	exec ('sp_synch_Tab_Agent_Conjoint '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Enfants'
	exec ('sp_synch_Tab_Agent_Enfants '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Criteres_Evaluation_Formations'
	exec ('sp_synch_Tab_Criteres_Evaluation_Formations '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Organismes_Formations'
	exec ('sp_synch_Tab_Organismes_Formations '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Formations'
	exec ('sp_synch_Tab_Formations '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Formation_Competence'
	exec ('sp_synch_Tab_Formation_Competence '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Formation_Evaluation'
	exec ('sp_synch_Tab_Formation_Evaluation '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Formation'
	exec ('sp_synch_Tab_Agent_Formation '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Objectifs_Formation'
	exec ('sp_synch_Tab_Objectifs_Formation '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Evaluation_Agent_Formation'
	exec ('sp_synch_Tab_Evaluation_Agent_Formation '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Information_Complementaire'
	exec ('sp_synch_Tab_Agent_Information_Complementaire '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Pret'
	exec ('sp_synch_Tab_Agent_Pret '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Qualification'
	exec ('sp_synch_Tab_Agent_Qualification '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Decisions'
	exec ('sp_synch_Tab_Decisions '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Evenement_Agent'
	exec ('sp_synch_Tab_Evenement_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Carriere'
	exec ('sp_synch_Tab_Agent_Carriere '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Information_Bulletin_Agent'
	exec ('sp_synch_Tab_Information_Bulletin_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Mois_Paie_Archive'
	exec ('sp_synch_Tab_Mois_Paie_Archive '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Agent_Mois_Archive'
	exec ('sp_synch_Tab_Agent_Mois_Archive '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Archive_Paie'
	exec ('sp_synch_Tab_Archive_Paie '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Coordonnees'
	exec ('sp_synch_Tab_Coordonnees '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Performance_Agent'
	exec ('sp_synch_Tab_Performance_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Promotion_Agent'
	exec ('sp_synch_Tab_Promotion_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Reliquat_Conge_Annuel'
	exec ('sp_synch_Tab_Reliquat_Conge_Annuel '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Specialite_Agent'
	exec ('sp_synch_Tab_Specialite_Agent '''+@db_source+''','''+@code+''' ')
	
	print 'Consolidation de la table Tab_Apprenti_Maitre_Apprenti'
	exec ('sp_synch_Tab_Apprenti_Maitre_Apprenti '''+@db_source+''','''+@code+''' ')

END
go

