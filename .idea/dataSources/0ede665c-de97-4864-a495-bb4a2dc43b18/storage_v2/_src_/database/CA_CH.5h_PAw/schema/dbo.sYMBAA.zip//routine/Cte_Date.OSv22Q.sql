-----CREATE FUNCTION [Cte_Date]
CREATE FUNCTION [dbo].[Cte_Date] (
@Code_Parametre varchar(10)
) returns date

as 
begin
declare @Date_Param date
set @Date_Param=(SELECT CAST(REPLACE(Contenue_Parametre,';','') as date) AS Param_Date  FROM Tab_Constantes_Parametrables 
WHERE Code_Parametre = @Code_Parametre  AND Est_Bloquer = 0)
RETURN @Date_Param
end;
go

