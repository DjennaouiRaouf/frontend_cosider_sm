
---Fonction Scalaire

------CREATE Fonction scalaire Cte_Chaine
CREATE FUNCTION [dbo].[Cte_Chaine] (
@Code_Parametre varchar(10)
) returns varchar(max)

as 
begin
declare @Chaine_Param varchar(max)

set @Chaine_Param=(SELECT REPLACE(Contenue_Parametre,';','')  Param_Chaine FROM Tab_Constantes_Parametrables 
WHERE Code_Parametre = @Code_Parametre and Est_Bloquer=0 )
RETURN @Chaine_Param
end;
go

