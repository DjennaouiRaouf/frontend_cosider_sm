
CREATE   procedure sp_synch_Tab_Site @db_source varchar(max), @code varchar(max)
as
begin
DECLARE @sql_interne nvarchar(max) = 'MERGE [CA].[dbo].[Tab_Site] AS Target
USING ['+@db_source+'].[dbo].[Tab_Site] AS Source
ON (1=1 and ( Target.[Code_site] = Source.[Code_site] ))
WHEN MATCHED and (Source.[date_modification] > Target.[Date_Modification])
THEN
UPDATE SET Target.[Code_Filiale] = Source.[Code_Filiale],
Target.[Code_Region] = Source.[Code_Region],
Target.[Libelle_Site] = Source.[Libelle_Site],
Target.[Code_Agence] = ('''+@code+'''+Source.[Code_Agence]),
Target.[Type_Site] = Source.[Type_Site],
Target.[Code_Commune_Site] = Source.[Code_Commune_Site],
Target.[Jour_Cloture_Mouv_RH_Paie] = Source.[Jour_Cloture_Mouv_RH_Paie],
Target.[Date_Ouverture_Site] = Source.[Date_Ouverture_Site],
Target.[Date_Cloture_Site] = Source.[Date_Cloture_Site],
Target.[Est_Bloquer] = Source.[Est_Bloquer],
Target.[User_ID]= case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Target.[Date_Modification]=Source.[Date_Modification]
WHEN NOT MATCHED
THEN
INSERT (
[Code_site],
[Code_Filiale],
[Code_Region],
[Libelle_Site],
[Code_Agence],
[Type_Site],
[Code_Commune_Site],
[Jour_Cloture_Mouv_RH_Paie],
[Date_Ouverture_Site],
[Date_Cloture_Site],
[Est_Bloquer],
[User_ID],
[Date_Modification]

)
VALUES (
Source.[Code_site],
Source.[Code_Filiale],
Source.[Code_Region],
Source.[Libelle_Site],
('''+@code+'''+Source.[Code_Agence]),
Source.[Type_Site],
Source.[Code_Commune_Site],
Source.[Jour_Cloture_Mouv_RH_Paie],
Source.[Date_Ouverture_Site],
Source.[Date_Cloture_Site],
Source.[Est_Bloquer],
case when ( Source.[User_ID] is not Null and Source.[User_ID] != ''null'' ) then ('''+@code+'''+Source.[User_ID]) else Null end ,
Source.[Date_Modification]

);'
exec (@sql_interne)
end
go

